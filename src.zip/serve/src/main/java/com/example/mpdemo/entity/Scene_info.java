package com.example.mpdemo.entity;

public class Scene_info {
    String token;
    String name;
    String scenename;
    String date;
    String msg;
    int type;

    public String getScenename() {
        return scenename;
    }

    public void setScenename(String scene_name) {
        this.scenename = scene_name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Scene_info{" +
                "token='" + token + '\'' +
                ", name='" + name + '\'' +
                ", scenename='" + scenename + '\'' +
                ", date='" + date + '\'' +
                ", msg='" + msg + '\'' +
                ", type=" + type +
                '}';
    }
}
