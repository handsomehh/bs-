package com.example.mpdemo.entity;

public class Device_info {
    String username;
    String token;
    String scenename;
    String roomname;
    String devicename;
    int type;
    int switcher;
    int light;
    int temperature;
    int dampness;
    String msg;
    String date;
    double pointx;
    double pointy;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getScenename() {
        return scenename;
    }

    public void setScenename(String scenename) {
        this.scenename = scenename;
    }

    public String getRoomname() {
        return roomname;
    }

    public void setRoomname(String roomname) {
        this.roomname = roomname;
    }

    public String getDevicename() {
        return devicename;
    }

    public void setDevicename(String devicename) {
        this.devicename = devicename;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getSwitcher() {
        return switcher;
    }

    public void setSwitcher(int switcher) {
        this.switcher = switcher;
    }

    public int getLight() {
        return light;
    }

    public void setLight(int light) {
        this.light = light;
    }

    public int getTemperature() {
        return temperature;
    }

    public void setTemperature(int temperature) {
        this.temperature = temperature;
    }

    public int getDampness() {
        return dampness;
    }

    public void setDampness(int dampness) {
        this.dampness = dampness;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public double getPointx() {
        return pointx;
    }

    public void setPointx(double pointx) {
        this.pointx = pointx;
    }

    public double getPointy() {
        return pointy;
    }

    public void setPointy(double pointy) {
        this.pointy = pointy;
    }

    @Override
    public String toString() {
        return "Device_info{" +
                "username='" + username + '\'' +
                ", token='" + token + '\'' +
                ", scenename='" + scenename + '\'' +
                ", roomname='" + roomname + '\'' +
                ", devicename='" + devicename + '\'' +
                ", type=" + type +
                ", switcher=" + switcher +
                ", light=" + light +
                ", temperature=" + temperature +
                ", dampness=" + dampness +
                ", msg='" + msg + '\'' +
                ", date='" + date + '\'' +
                ", pointx=" + pointx +
                ", pointy=" + pointy +
                '}';
    }
}
