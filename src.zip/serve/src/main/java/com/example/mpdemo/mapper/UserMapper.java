package com.example.mpdemo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.mpdemo.entity.*;
import org.apache.ibatis.annotations.*;

import java.util.List;

//用于操作用户表,MyBaits会根据Mapper注解，动态实现UserMapper接口（实现类），动态代理技术
//Spring会自动创建UserMapper接口实现类对应的实例
@Mapper
public interface UserMapper {
    @Update("update room_info set picture=#{s} where username = #{uname} and scenename = #{scenename} and roomname = #{roomname}")
     int updaateroompic(String uname, String scenename, String roomname, String s);

    @Insert("insert into user_details values(#{username},'','',18,'',1,'','','')")
    int insert_details(User user);

    //   查询用户，根据用户id查询信息   select * from user where id =
    @Select("select * from user_info where username = #{id}")
    User find_username(String id);

    @Insert("insert into user_info values(#{username},#{password},#{phone})")
    int insert(User user);
    @Select("select * from user_details where id = #{username}")
    User_details find_userdetails(User user);
    @Update("update user_details set avatar=#{avatar},nickname=#{nickname},age=#{age},email=#{email},sex = #{sex},area=#{area},hobby=#{hobby},work=#{work} where id = #{id}")
    @Options(useGeneratedKeys = false)
    int update_details(User_details user);
    @Update("update user_info set password=#{password},phone=#{phone} where username = #{username}")
    @Options(useGeneratedKeys = false)
    int update_userinfo(User temp);
    @Select("select * from scene_info where username=#{name} and type = #{type}")
    List<Scene_info> find_scenes(String name, int type);
    @Insert("insert into scene_info values(#{name},#{scenename}, #{date},#{msg},#{type})")
    int insert_scenes(Scene_info user);
    @Delete("delete from scene_info where username=#{name} and scenename=#{scenename};delete from room_info where username=#{name} and scenename=#{scenename};delete from device_info where username=#{name} and scenename=#{scenename}")
    int delete_scenes(String name, String scenename);
//    @Delete("delete from scene_info where username=#{name} and scenename=#{scenename}")
//    int delete_scenes(String name, String scenename);
//
//    @Delete("delete from scene_info where username=#{name} and scenename=#{scenename}")
//    int delete_scenes(String name, String scenename);
    @Select("select T.roomname,T.date,T.msg,T.picture,count(T.devicename)-1 as number\n" +
            "from \n" +
            "(select  room_info.username, room_info.scenename,room_info.roomname,room_info.date,room_info.msg,room_info.picture,device_info.devicename\n" +
            "from room_info , device_info\n" +
            "where room_info.username=device_info.username and room_info.username=#{name} \n" +
            "\tand  room_info.scenename=device_info.scenename  and room_info.scenename=#{scenename}\n" +
            "    and room_info.roomname=device_info.roomname  \n" +
            ") as T\n" +
            "group by T.roomname")
    List<Room_info> get_rooms(String name, String scenename);


    @Insert("insert into room_info values(#{name},#{scenename},#{roomname},#{date},#{msg},#{picture})")
    int insert_room(Room_info scene_info);
    @Insert("insert into device_info values(#{name},#{scenename},#{roomname},'-1',-1,2,3,4,5,'','',6,7)")
    int insert_flat_device(Room_info scene_info);
    @Delete("delete from room_info where username=#{name} and scenename = #{scenename} and roomname=#{roomname}")
    int delete_room(String name, String scenename, String roomname);
    @Delete("delete from device_info where username=#{name} and scenename = #{scenename} and roomname=#{roomname}")
    int delete_room_device(String name, String scenename, String roomname);
    @Select("select * from room_info  where username=#{name} and scenename = #{scenename} and roomname=#{roomname}")
    Room_info get_oneroom(String name, String scenename, String roomname);
    @Select("select * from device_info where username=#{name} and scenename = #{scenename} and roomname=#{roomname} and type != -1")
    List<Device_info> devicelist(String name, String scenename, String roomname);
    @Insert("insert into device_info values(#{username},#{scenename},#{roomname},#{devicename},#{type},#{switcher},#{light},#{temperature},#{dampness},#{msg},#{date},#{pointx},#{pointy})")
    int insert_one_device(Device_info scene_info);
@Delete("delete from device_info where username=#{name} and scenename = #{scenename} and roomname=#{roomname} and devicename=#{devicename}")
    int delete_one_device(String name, String scenename, String roomname, String devicename);
    @Update("update device_info set devicename=#{devicename},switcher=#{switcher},light=#{light},temperature=#{temperature},dampness=#{dampness},msg=#{msg},date=#{date} where username=#{username} and scenename = #{scenename} and roomname=#{roomname} and devicename=#{devicename}")
    @Options(useGeneratedKeys = false)
    int update_one_device(Device_info scene_info);
@Update("update room_info set picture=#{picture} where username=#{name} and scenename = #{scenename} and roomname=#{roomname}")
    int update_pic(String name, String scenename, String roomname, String picture);
    @Select("select count(*) from scene_info where username=#{name}")
    int changjingshuliang(String name);
    @Select("select count(*) from device_info where username=#{name} and type != -1")
    int shebeishuliang(String name);
@Update("update scene_info set msg = #{msg}, date = #{date} where username=#{name} and scenename = #{scenename}")
    int room_update(Room_info scene_info);
    @Update("update room_info set msg = #{msg}, date = #{date} where username=#{name} and scenename = #{scenename} and roomname = #{roomname}")
    int roommsg_update(Room_info scene_info);
    @Select("select * from device_info where username=#{name} and type != -1")
    List<Device_info> alldevice(String name);
}
