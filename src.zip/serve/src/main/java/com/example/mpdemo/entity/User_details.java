package com.example.mpdemo.entity;

import com.baomidou.mybatisplus.annotation.TableName;

@TableName("user_details")
public class User_details{
    String code;
    String avatar;
    String password;
    String nickname;
    int age;
    String email;
    String phone;
    int sex;
    String id;
    String area;
    String hobby;
    String work;

    String token;
//    public User_details(String code) {
//        this.code = code;
//    }

//    public User_details(String avatar, String password, String nickname, int age, String email, String phone, int sex, String id, String area, String hobby, String work, String token) {
//        this.avatar = avatar;
//        this.password = password;
//        this.nickname = nickname;
//        this.age = age;
//        this.email = email;
//        this.phone = phone;
//        this.sex = sex;
//        this.id = id;
//        this.area = area;
//        this.hobby = hobby;
//        this.work = work;
//        this.token = token;
//    }
//
//    public User_details() {
//
//    }

//    public User_details( String avatar, String nickname, int age, String email, int sex, String id, String area, String hobby, String work) {
//        this.avatar = avatar;
//        this.nickname = nickname;
//        this.age = age;
//        this.email = email;
//        this.sex = sex;
//        this.id = id;
//        this.area = area;
//        this.hobby = hobby;
//        this.work = work;
//    }

//    public User_details(String avatar, String password, String nickname, int age, String email, String phone, int sex, String id, String area, String hobby, String work, String token) {
//        this.avatar = avatar;
//        this.password = password;
//        this.nickname = nickname;
//        this.age = age;
//        this.email = email;
//        this.phone = phone;
//        this.sex = sex;
//        this.id = id;
//        this.area = area;
//        this.hobby = hobby;
//        this.work = work;
//        this.token = token;
//    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getHobby() {
        return hobby;
    }

    public void setHobby(String hobby) {
        this.hobby = hobby;
    }

    public String getWork() {
        return work;
    }

    public void setWork(String work) {
        this.work = work;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public String toString() {
        return "User_details{" +
                "code='" + code + '\'' +
                ", avatar='" + avatar + '\'' +
                ", password='" + password + '\'' +
                ", nickname='" + nickname + '\'' +
                ", age=" + age +
                ", email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                ", sex=" + sex +
                ", id='" + id + '\'' +
                ", area='" + area + '\'' +
                ", hobby='" + hobby + '\'' +
                ", work='" + work + '\'' +
                ", token='" + token + '\'' +
                '}';
    }
}