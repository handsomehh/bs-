package com.example.mpdemo.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mpdemo.entity.*;
import com.example.mpdemo.mapper.UserMapper;
import com.example.mpdemo.utils.Jwt;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import sun.text.resources.FormatData;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@RestController
@CrossOrigin
public class UserContoller {
    @Value("${spring.web.resources.static-locations}")
    private String staticPath;
    @Autowired
    UserMapper userMapper;

    @GetMapping("/login")
    public Response_login find( User user){
        User temp = null;
        System.out.println(user);
        if((temp = userMapper.find_username(user.getUsername()))==null){
            System.out.println("not exist");
            return new Response_login("405","");
        }else{
            System.out.println(temp);
        }
        if(temp.getPassword().equals(user.getPassword())){
            System.out.println(user+"登录成功");
            return new Response_login("200",Jwt.generate(user.getUsername()));
        }else{
            return new Response_login("406","");
        }
    }
    @GetMapping("/login2")
    public String find2( User user){
        User temp = null;
        System.out.println(user);
        return "111";
    }
//  插入数据
    @PostMapping("/Register")
    public Response_login save(@RequestBody User user){
        System.out.println(user);
        if(user.getPhone().length()!=11||user.getUsername().length()>15||user.getUsername().length()<=5||user.getPassword().length()>=16||user.getPassword().length()<=5)
            return new Response_login("405","");
        int r= userMapper.insert(user);
        int s = userMapper.insert_details(user);
        if(r > 0&&s>0){
            return new Response_login("200","");
        }else{
            return new Response_login("405","");
        }
    }
    @GetMapping("/person/details")
    public User_details find_details(String token){
        String name = Jwt.GetClaimByToken(token).getSubject();
        System.out.println(name);
        User temp = null;
        if((temp = userMapper.find_username(name))==null){
            System.out.println("not exist");
            User_details r = new User_details();
            r.setCode("405");
            return r;
        }
        User_details  ret = userMapper.find_userdetails(temp);
        ret.setCode("200");
        ret.setId(name);
        ret.setPassword(temp.getPassword());
        ret.setPhone(temp.getPhone());
        return ret;
    }
    @GetMapping("/room")
    public List<Scene_info> find_bed(String token,int type){
        String name = Jwt.GetClaimByToken(token).getSubject();
        System.out.println(name);
        System.out.println(type);
        User temp = null;
        if((temp = userMapper.find_username(name))==null){
            System.out.println("not exist");
            return null;
        }
        List<Scene_info>  ret = userMapper.find_scenes(name,type);
        System.out.println(ret);
        return ret;
    }
    @GetMapping("/roomdelete")
    public Response_login delete_bed(String token,int type,String scenename){
        String name = Jwt.GetClaimByToken(token).getSubject();
        System.out.println(name);
        System.out.println(type);
        User temp = null;
        if((temp = userMapper.find_username(name))==null){
            System.out.println("not exist");
            return new Response_login("500");
        }
        int ret = userMapper.delete_scenes(name,scenename);
        if(ret>0){
            return new Response_login("200");
        }
        return new Response_login("405");
    }
    @GetMapping("/roomlistdelete")
    public Response_login delete_room(String token,String roomname,String scenename){
        String name = Jwt.GetClaimByToken(token).getSubject();
        System.out.println(name);
        System.out.println(roomname);
        User temp = null;
        if((temp = userMapper.find_username(name))==null){
            System.out.println("not exist");
            return new Response_login("500");
        }
        int ret = userMapper.delete_room(name,scenename,roomname);
        int ret2 = userMapper.delete_room_device(name,scenename,roomname);
        if(ret>0&&ret2>0){
            return new Response_login("200");
        }
        return new Response_login("405");
    }
    @GetMapping("/one_device_delete")
    public Response_login one_device_delete(String token,String roomname,String scenename,String devicename){
        String name = Jwt.GetClaimByToken(token).getSubject();
        System.out.println(name);
        System.out.println(roomname);
        User temp = null;
        if((temp = userMapper.find_username(name))==null){
            System.out.println("not exist");
            return new Response_login("500");
        }
        int ret = userMapper.delete_one_device(name,scenename,roomname,devicename);
        if(ret>0){
            return new Response_login("200");
        }
        return new Response_login("405");
    }
    @GetMapping("/roomlist")
    public List<Room_info> getroomlist(String token, int type, String scenename){
        System.out.println("roomlist=>"+scenename);
        String name = Jwt.GetClaimByToken(token).getSubject();
        System.out.println(name);
        System.out.println(type);
        User temp = null;
        if((temp = userMapper.find_username(name))==null){
            System.out.println("not exist");
            return null;
        }
        List<Room_info> ret = null;
        ret = userMapper.get_rooms(name,scenename);
//        int number = userMapper.get_rooms_device_number(name,scenename);
        System.out.println(ret);
        return ret;
    }

    @GetMapping("/devicelist_room")
    public Room_info devicelist_room(String token, String roomname, String scenename){
        System.out.println("roomlist=>"+scenename);
        String name = Jwt.GetClaimByToken(token).getSubject();
        System.out.println(name);

        User temp = null;
        if((temp = userMapper.find_username(name))==null){
            System.out.println("not exist");
            return null;
        }
        Room_info ret = null;
        ret = userMapper.get_oneroom(name,scenename,roomname);
//        int number = userMapper.get_rooms_device_number(name,scenename);
        System.out.println(ret);
        return ret;
    }

    @GetMapping("/devicelist")
    public List<Device_info> devicelist(String token, String roomname, String scenename){
        System.out.println("roomlist=>"+scenename+" "+roomname);
        String name = Jwt.GetClaimByToken(token).getSubject();
        System.out.println(name);
        User temp = null;
        if((temp = userMapper.find_username(name))==null){
            System.out.println("not exist");
            return null;
        }
        List<Device_info> ret = null;
        ret = userMapper.devicelist(name,scenename,roomname);
//        int number = userMapper.get_rooms_device_number(name,scenename);
        System.out.println(ret);
        return ret;
    }
    @GetMapping("/alldevice")
    public List<Device_info> alldevice(String token){
        String name = Jwt.GetClaimByToken(token).getSubject();
        System.out.println(name);
        User temp = null;
        if((temp = userMapper.find_username(name))==null){
            System.out.println("not exist");
            return null;
        }
        List<Device_info> ret = null;
        ret = userMapper.alldevice(name);
//        int number = userMapper.get_rooms_device_number(name,scenename);
        System.out.println(ret);
        return ret;
    }
    @GetMapping("/images/{imagesname}")
    public ResponseEntity<byte[]> devicelist(@PathVariable String imagesname){

        // 创建 BufferedImage 对象
        BufferedImage image = null;
        try {
            System.out.println("./"+imagesname);
            image = ImageIO.read(new File(ResourceUtils.getURL("classpath:").getPath()+"static/"+imagesname));
            // 创建字节输出流
            ByteArrayOutputStream baos = new ByteArrayOutputStream();

// 将图片写入字节输出流

            ImageIO.write(image, imagesname.substring(imagesname.lastIndexOf(".")+1,imagesname.length()), baos);
            byte[] imageBytes = baos.toByteArray();
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.IMAGE_JPEG);

            // 返回响应
            return new ResponseEntity<>(imageBytes, headers, HttpStatus.OK);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    @PostMapping("/roomlist")
    public Response_login postroomlist(@RequestBody Room_info scene_info){
        System.out.println(scene_info);
        String name = Jwt.GetClaimByToken(scene_info.getToken()).getSubject();
        System.out.println(name);

        User temp = null;
        if((temp = userMapper.find_username(name))==null){
            System.out.println("not exist");
            return new Response_login("405");
        }

        scene_info.setName(name);
        int ret = userMapper.insert_room(scene_info);
        System.out.println(ret);
        int ret2 = userMapper.insert_flat_device(scene_info);
        if(ret>0&&ret2>0){
            return new Response_login("200");
        }
        return new Response_login("405");
    }

    @PostMapping("/roommsg_update")
    public Response_login roommsg_update(@RequestBody Room_info scene_info){
        System.out.println(scene_info);
        String name = Jwt.GetClaimByToken(scene_info.getToken()).getSubject();
        System.out.println(name);

        User temp = null;
        if((temp = userMapper.find_username(name))==null){
            System.out.println("not exist");
            return new Response_login("405");
        }

        scene_info.setName(name);
        int ret = userMapper.roommsg_update(scene_info);

        if(ret>0){
            return new Response_login("200");
        }
        return new Response_login("405");
    }
    @PostMapping("/room_update")
    public Response_login room_update(@RequestBody Room_info scene_info){
        System.out.println(scene_info);
        String name = Jwt.GetClaimByToken(scene_info.getToken()).getSubject();
        System.out.println(name);

        User temp = null;
        if((temp = userMapper.find_username(name))==null){
            System.out.println("not exist");
            return new Response_login("405");
        }

        scene_info.setName(name);
        int ret = userMapper.room_update(scene_info);

        if(ret>0){
            return new Response_login("200");
        }
        return new Response_login("405");
    }
    @PostMapping("/upload_pic")
    public Response_login upload_pic(MultipartFile file,String token,String scenename,String roomname){
        System.out.println(token+scenename+roomname);
        String uname = Jwt.GetClaimByToken(token).getSubject();
        System.out.println(uname);
        User temp = null;
        if((temp = userMapper.find_username(uname))==null){
            System.out.println("not exist");
            return new Response_login("402");
        }
       System.out.println(file.getOriginalFilename());
        String name=file.getOriginalFilename();
        System.out.println(file.getSize());
        //获取文件后缀
        assert name != null;
        String subffix=name.substring(name.lastIndexOf(".")+1,name.length());
        //控制格式
        if(!subffix.equals("jpg")&&!subffix.equals("jpeg")&&!subffix.equals("png")&&!subffix.equals("svg")&&!subffix.equals("bmp"))
        {
            return new Response_login("406");
        }
        //新的文件名以日期命名
        String fileName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        //获取项目路径到webapp
        //保存文件

        try {
//            File file2=new File(path);
//            if(!file2.exists())//文件夹不存在就创建
//            {
//                file2.mkdirs();
//            }
            file.transferTo(new File(ResourceUtils.getURL("classpath:").getPath()+"static/"+fileName+"."+subffix));
            userMapper.updaateroompic(uname,scenename,roomname,"/images/"+fileName+"."+subffix);
            return new Response_login("200",fileName+"."+subffix);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new Response_login("400",fileName+"."+subffix);
    }

    @PostMapping("/teste")
    public void devicelistsada(MultipartFile file) throws FileNotFoundException {

        String path = ResourceUtils.getURL("classpath:").getPath();
        File uploadDir = new File(path+"static/");
        if (!uploadDir.exists()) {
            System.out.println("上传头像路径不存在，正在创建...");
            uploadDir.mkdir();
        }
        if ( file != null) {
            //获得上传文件的文件名
            String oldName = file.getOriginalFilename();
            System.out.println("[上传的文件名]：" + oldName);
            //我的文件保存在static目录下的avatar/user

            File avatar = new File(path + "static/" , oldName);
            try {
                //保存图片
                file.transferTo(avatar);
                //返回成功结果，附带文件的相对路径
            }catch (IOException e) {
                e.printStackTrace();
            }
        }else {
            System.out.println("上传的文件为空");
        }
    }
    @PostMapping("/Scene_List/Room_List/Device")
    public Response_login Scene_List_Room_List_Device(@RequestBody Device_info scene_info){
        System.out.println(scene_info);
        String name = Jwt.GetClaimByToken(scene_info.getToken()).getSubject();
        System.out.println(name);

        User temp = null;
        if((temp = userMapper.find_username(name))==null){
            System.out.println("not exist");
            return new Response_login("405");
        }

        scene_info.setUsername(name);
        int ret = userMapper.insert_one_device(scene_info);
        if(ret>0){
            return new Response_login("200");
        }
        return new Response_login("405");
    }
    @PostMapping("/room")
    public Response_login sub_bed(@RequestBody Scene_info scene_info){
        System.out.println(scene_info);
        String name = Jwt.GetClaimByToken(scene_info.getToken()).getSubject();
        System.out.println(name);

        User temp = null;
        if((temp = userMapper.find_username(name))==null){
            System.out.println("not exist");
            return new Response_login("405");
        }
        scene_info.setName(name);
        int ret = userMapper.insert_scenes(scene_info);
        System.out.println(ret);
        if(ret>0){
            return new Response_login("200");
        }
        return new Response_login("405");
    }
    @PostMapping("/person/details")
    public Response_login update_details(@RequestBody User_details user){
        System.out.println(user);
        String name = Jwt.GetClaimByToken(user.getToken()).getSubject();
        System.out.println(name);
        User temp = null;
        if((temp = userMapper.find_username(name))==null){
            System.out.println("not exist");
            return new Response_login("405");
        }
        temp.setPhone(user.getPhone());
        temp.setPassword(user.getPassword());
        System.out.println(user);
        userMapper.update_userinfo(temp);
        userMapper.update_details(user);

        return new Response_login("200");
    }
    @GetMapping("/update_pic")
    public Response_login update_pic(String token, String scenename,String roomname,String picture){
        String name = Jwt.GetClaimByToken(token).getSubject();
        System.out.println(name);
        User temp = null;
        if((temp = userMapper.find_username(name))==null){
            System.out.println("not exist");
            return new Response_login("405");
        }
        userMapper.update_pic(name,scenename,roomname,picture);
        return new Response_login("200");
    }
    @GetMapping("/changjingshuliang")
    public Response_login changjingshuliang(String token){
        String name = Jwt.GetClaimByToken(token).getSubject();
        System.out.println(name);
        User temp = null;
        if((temp = userMapper.find_username(name))==null){
            System.out.println("not exist");
            return new Response_login("405");
        }
        int num = userMapper.changjingshuliang(name);
        return new Response_login("200","",num);
    }
    @GetMapping("/shebeishuliang")
    public Response_login shebeishuliang(String token){
        String name = Jwt.GetClaimByToken(token).getSubject();
        System.out.println(name);
        User temp = null;
        if((temp = userMapper.find_username(name))==null){
            System.out.println("not exist");
            return new Response_login("405");
        }
        int num = userMapper.shebeishuliang(name);
        return new Response_login("200","",num);
    }
    @PostMapping("/Scene_List/Room_List/Device_update")
    public Response_login Device_update(@RequestBody Device_info scene_info){
//        System.out.println(user);
//        String name = Jwt.GetClaimByToken(user.getToken()).getSubject();
//        System.out.println(name);
//        User temp = null;
//        if((temp = userMapper.find_username(name))==null){
//            System.out.println("not exist");
//            return new Response_login("405");
//        }
//        temp.setPhone(user.getPhone());
//        temp.setPassword(user.getPassword());
//        System.out.println(user);
//        userMapper.update_userinfo(temp);
//        userMapper.update_details(user);
        System.out.println(scene_info);
        String name = Jwt.GetClaimByToken(scene_info.getToken()).getSubject();
        System.out.println(name);

        User temp = null;
        if((temp = userMapper.find_username(name))==null){
            System.out.println("not exist");
            return new Response_login("405");
        }

        scene_info.setUsername(name);
        int ret = userMapper.update_one_device(scene_info);
        return new Response_login("200");
//        return new Response_login("200");
    }
}

class Response_login{
    String code;
    String token;
    int number;

    public Response_login(String code, String token, int number) {
        this.code = code;
        this.token = token;
        this.number = number;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }


    Response_login(String code,String token){
        this.code = code;
        this.token = token;
    }

    public Response_login(String code) {
        this.code = code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getCode() {
        return code;
    }

    public String getToken() {
        return token;
    }
}