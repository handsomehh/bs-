import Vue from "vue";
import App from "./App.vue";
import ElementUI from "element-ui";
import "element-ui/lib/theme-chalk/index.css";
import router from "./router/index";
import "../font_icon/iconfont.css";
import vuescroll from "vuescroll";
import axios from "axios";
import store from "./store";
// import Paintable from "vue-paintable";
Vue.config.productionTip = false;
Vue.use(ElementUI);
Vue.use(vuescroll);
// Vue.use(axios);
axios.defaults.baseURL = "http://192.168.43.84:8088";
Vue.prototype.$http = axios;
new Vue({
  el: "#app",
  render: (h) => h(App),
  router: router,
  store: store,
}).$mount("#app");
