<template>
  <div class="loginbody">
    <div class="logindata">
      <div class="logintext">
        <h2>Welcome</h2>
      </div>
      <div class="formdata">
        <el-form ref="form" :model="form" :rules="rules">
          <el-form-item prop="username">
            <el-input
              v-model="form.username"
              clearable
              placeholder="请输入账号"
            ></el-input>
          </el-form-item>
          <el-form-item prop="password">
            <el-input
              v-model="form.password"
              clearable
              placeholder="请输入密码"
              show-password
            ></el-input>
          </el-form-item>
          <el-form-item prop="phone">
            <el-input
              v-model="form.phone"
              clearable
              placeholder="请输入手机号"
            ></el-input>
          </el-form-item>
        </el-form>
        <div class="tool">
          
        <!-- <div>
          <el-checkbox v-model="checked" @change="remenber"
            >记住密码</el-checkbox
          >
        </div> -->
        <div>
          <router-link to = "/login">点我返回</router-link>
        </div>
      </div>
      <div class="butt">
        <el-button class="shou" @click="register" style="width:100%;">注册</el-button>
      </div>
      </div>
      
      
    </div>
  </div>
</template>

<script>
// import { login } from "@/api/login";
// import { setToken } from "@/request/auth";

export default {
  name: "login",
  data() {
    return {
      form: {
        password: "",
        username: "",
        phone:"",
      },
      checked: false,
      rules: {
        username: [
          { required: true, message: "请输入用户名", trigger: "blur" },
          { max: 15,min:6, message: "请介于6-15位", trigger: "blur" },
        ],
        password: [
          { required: true, message: "请输入密码", trigger: "blur" },
          { max: 15, min:6,message: "请介于6-15位", trigger: "blur" },
        ],
        phone: [
          { required: true, message: "请输入电话号码", trigger: "blur" },
          { pattern: /^1[3|4|5|6|7|8|9][0-9]\d{8}$/, message: "非法的电话号码", trigger: "blur" },
        ],
      },
    };
  },
  mounted() {
      if(localStorage.getItem("news")){
        this.form=JSON.parse(localStorage.getItem("news"))
        this.checked=true
      }
  },
  methods: {
    valid(){
      let ret=-1;
      if(this.form.password.length>10||this.form.password.length<=5){
        alert("密码不规范");
      }else if(this.form.username.length>10||this.form.username.length<=5){
        alert("用户名不规范");
      }else if(this.form.phone.length!=11){
        alert("电话号码格式错误");
      }else{
        ret=1;
      }
      return ret;
    },
    register() {
      console.log(this.form.password);
      console.log(this.form.phone);
      console.log(this.form.username);
      let temp = this.valid();
      console.log(temp);
      if(temp!=1){
        return;
      }{
        this.$http(
          { url:'/Register',
            method :'post',
            data:{
              username:this.form.username,
              phone:this.form.phone,
              password:this.form.password,
            }
          }).then(
          (res)=>{
            console.log(res);
            if(res.data.code=="200"){
              this.$router.push('/login');
              alert("注册成功");
            }else{
              alert("注册失败，用户名不唯一或输入格式不正确");
            }
          }
        ).catch(
          (res)=>{
            console.log(res);
          }
        );
      }
    },
  },
};
</script>

<style scoped>
.loginbody {
  width: 100%;
  height: 100%;
  min-width: 1000px;
  background-image: url("../../assets/images/login-bg.jpg");
  background-size: 100% 100%;
  background-position: center center;
  overflow: auto;
  background-repeat: no-repeat;
  position: fixed;
  line-height: 100%;
  padding-top: 150px;
}

.logintext {
  margin-bottom: 20px;
  line-height: 50px;
  text-align: center;
  font-size: 30px;
  font-weight: bolder;
  color: white;
  text-shadow: 2px 2px 4px #000000;
}

.logindata {
  width: 400px;
  height: 300px;
  transform: translate(-50%);
  margin-left: 50%;
}

.tool {
  display: flex;
  justify-content: space-between;
  color: #606266;
}

.butt {
  margin-top: 10px;
  text-align: center;
  width: 100%;
}

.shou {
  cursor: pointer;
  color: #606266;
}
.formdata{
  padding: 30px;
  border-radius: 5%;
  background-color: #b8b9bc;
}
</style>