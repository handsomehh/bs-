<template>
  <div>
    <div v-if="isPC" class="Top">
      <div class="left">
        <div id="bejing2" >
          <canvas id="mycanvas" @click="dianjihuamu">浏览器不支持canvas</canvas>
        </div>
        <div class="bottom">
          <div style="padding:10px">
            <el-button type="primary" round icon="iconfont icon-taideng" @click="taideng">添加台灯</el-button>
              <el-button type="primary" round  icon="iconfont icon-men-mensuo-kai-05" @click="mengsuo">添加门锁</el-button>
              <el-button type="primary" round icon="iconfont icon-wenshiduchuanganqi_o" @click="chuanganqi">添加传感器</el-button>
              <el-button type="primary" round  icon="iconfont icon-kaiguan" @click="kaiguan">添加开关</el-button>
              <el-button type="primary" round  @click="shiyongbeijingmoban">使用背景模板</el-button>
              <!-- :on-success="handlePreview"
              :on-error="handleRemove"
              :on-change="handleChange" -->
              <el-upload
              style="width:135px;display: inline-block;"
              :show-file-list="false"
              class="upload-demo"
              action="http://localhost:8088/upload_pic"
              enctype="multipart/form-data"
              :on-success="handlePreview"
              :data="head_info"
              ref="upload">
              <el-button slot="trigger" type="primary" name="file" round  >上传背景图</el-button>
            </el-upload>
            

            <!-- <i ref="icon" class="fa fa-home" icon="iconfont icon-taideng"></i> -->
          </div>
        </div>
      </div>
      <div class="right">


          <el-table
            :data="tableData"
            style="width: 100%"
            max-height="90%">
            <el-table-column
              label="日期"
              width="">
              <template slot-scope="scope">
                <i class="el-icon-time"></i>
                <span style="margin-left: 10px">{{ scope.row.date }}</span>
              </template>
            </el-table-column>
            <el-table-column
              label="设备名称"
              width="">
              <template slot-scope="scope">
                <el-popover trigger="hover" placement="top">
                  <p>备注: {{ scope.row.msg }}</p>
                  <div slot="reference" class="name-wrapper">
                    <el-tag size="medium">{{ scope.row.devicename }}</el-tag>
                  </div>
                </el-popover>
              </template>
            </el-table-column>
            <el-table-column label="操作">
              <template slot-scope="scope">
                <el-button
                  size="mini"
                  @click="handleEdit(scope.$index, scope.row)">编辑属性</el-button>
                <el-button
                  size="mini"
                  type="danger"
                  @click="handleDelete(scope.$index, scope.row)">删除</el-button>
              </template>
            </el-table-column>
          </el-table>
        <div class="sub"> 
          <el-button type="primary" icon="el-icon-document-delete" @click="ret">返回</el-button>  
        </div>
        
      </div>
    </div>

    <div v-if="!isPC" class="Top2">
      <el-dialog
      title="查看设备属性"
      :visible.sync="dialogVisible4"
      width="90vw"
      :before-close="handleClose">
      <div class="left2">
          <div id="bejing2">
          <canvas id="mycanvas" @click="dianjihuamu">浏览器不支持canvas</canvas>
        </div>
      </div>
    </el-dialog>
      <div class="right2">


          <el-table
            :data="tableData"
            style="width: 100%"
            max-height="90%">
            <el-table-column
              label="日期"
              width="">
              <template slot-scope="scope">
                <i class="el-icon-time"></i>
                <span style="margin-left: 10px">{{ scope.row.date }}</span>
              </template>
            </el-table-column>
            <el-table-column
              label="设备名称"
              width="">
              <template slot-scope="scope">
                <el-popover trigger="hover" placement="top">
                  <p>备注: {{ scope.row.msg }}</p>
                  <div slot="reference" class="name-wrapper">
                    <el-tag size="medium">{{ scope.row.devicename }}</el-tag>
                  </div>
                </el-popover>
              </template>
            </el-table-column>
            <el-table-column label="操作">
              <template slot-scope="scope">
                <el-button
                  size="mini"
                  @click="handleEdit(scope.$index, scope.row)">编辑属性</el-button>
                
              </template>
            </el-table-column>
          </el-table>
        <div class="sub"> 
          <el-button type="primary" icon="el-icon-document-delete" @click="ret">返回</el-button>  
          <el-button type="primary"  @click="tuxinghua">图形化</el-button>  
        </div>
        
      </div>
    </div>

    <el-dialog
      title="创建一个新的设备"
      :visible.sync="dialogVisible"
      width="30%"
      :before-close="handleClose">
      <el-form :model="newicon" :rules="rules" ref="form" label-width="150px">

        <el-form-item label="名称" prop="scenename">
            <el-input maxlength="20" v-model="newicon.devicename"></el-input>
            </el-form-item>
        
        <el-form-item label="日期" prop="date">
          <el-input maxlength="20" v-model="newicon.date"></el-input>
        </el-form-item>
        
        <el-form-item label="备注消息" prop="msg">
          <el-input maxlength="20" v-model="newicon.msg"></el-input>
        </el-form-item> 
       
        <el-form-item v-if="(this.tianjiatype==1)" label="灯光亮度" prop="msg">
          <el-input type="number" placeholder="请输入数字" v-model="newicon.light"></el-input>
        </el-form-item> 

        <el-form-item v-if="(this.tianjiatype==3)" label="温度" prop="msg">
          <el-input type="number" placeholder="请输入数字" v-model="newicon.temperature"></el-input>
        </el-form-item> 

        <el-form-item v-if="(this.tianjiatype==3)" label="湿度" prop="msg">
          <el-input type="number" placeholder="请输入数字" v-model="newicon.dampness"></el-input>
        </el-form-item> 
        <el-form-item label="开关状态" prop="msg">
        <el-switch
              v-model="newicon.switcher"
              active-color="#13ce66"
              inactive-color="#ff4949"
              active-text="开"
              inactive-text="关"
              :active-value= "1"
               :inactive-value= "0"
            >
            </el-switch>
          </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">  
        <el-button @click="quxiaotianjia">取 消</el-button>
        <el-button type="primary" @click="quedingtianjia">确 定</el-button>
      </span>

    </el-dialog>


    <el-dialog
      title="编辑设备属性"
      :visible.sync="dialogVisible2"
      width="30%"
      :before-close="handleClose2">
      <el-form :model="newicon" :rules="rules" ref="form" label-width="150px">

        <el-form-item label="名称" prop="scenename">
            <el-input maxlength="20" v-model="newicon.devicename"></el-input>
            </el-form-item>
        
        <el-form-item label="日期" prop="date">
          <el-input maxlength="20" v-model="newicon.date"></el-input>
        </el-form-item>
        
        <el-form-item label="备注消息" prop="msg">
          <el-input maxlength="20" v-model="newicon.msg"></el-input>
        </el-form-item> 
       
        <el-form-item v-if="(this.tianjiatype==1)" label="灯光亮度" prop="msg">
          <el-input type="number" placeholder="请输入数字" v-model="newicon.light"></el-input>
        </el-form-item> 

        <el-form-item v-if="(this.tianjiatype==3)" label="温度" prop="msg">
          <el-input type="number" placeholder="请输入数字" v-model="newicon.temperature"></el-input>
        </el-form-item> 

        <el-form-item v-if="(this.tianjiatype==3)" label="湿度" prop="msg">
          <el-input type="number" placeholder="请输入数字" v-model="newicon.dampness"></el-input>
        </el-form-item> 
        <el-form-item label="开关状态" prop="msg">
        <el-switch
              v-model="newicon.switcher"
              active-color="#13ce66"
              inactive-color="#ff4949"
              active-text="开"
              inactive-text="关"
              :active-value= "1"
               :inactive-value= "0"
            >
            </el-switch>
          </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">  
        <el-button @click="quxiaotianjia2">取 消</el-button>
        <el-button type="primary" @click="quedingtianjia2">更新</el-button>
      </span>
    </el-dialog>

    <el-dialog
      title="编辑设备属性"
      :visible.sync="dialogVisible3"
      :before-close="handleClose3"
      width="90%">
      <el-form :model="newicon" :rules="rules" ref="form" label-width="150px">

        <el-form-item label="名称" prop="scenename">
            <el-input maxlength="20" v-model="newicon.devicename"></el-input>
            </el-form-item>
        
        <el-form-item label="日期" prop="date">
          <el-input maxlength="20" v-model="newicon.date"></el-input>
        </el-form-item>
        
        <el-form-item label="备注消息" prop="msg">
          <el-input maxlength="20" v-model="newicon.msg"></el-input>
        </el-form-item> 
       
        <el-form-item v-if="(this.tianjiatype==1)" label="灯光亮度" prop="msg">
          <el-input type="number" placeholder="请输入数字" v-model="newicon.light"></el-input>
        </el-form-item> 

        <el-form-item v-if="(this.tianjiatype==3)" label="温度" prop="msg">
          <el-input type="number" placeholder="请输入数字" v-model="newicon.temperature"></el-input>
        </el-form-item> 

        <el-form-item v-if="(this.tianjiatype==3)" label="湿度" prop="msg">
          <el-input type="number" placeholder="请输入数字" v-model="newicon.dampness"></el-input>
        </el-form-item> 
        <el-form-item label="开关状态" prop="msg">
        <el-switch
              v-model="newicon.switcher"
              active-color="#13ce66"
              inactive-color="#ff4949"
              active-text="开"
              inactive-text="关"
              :active-value= "1"
               :inactive-value= "0"
            >
            </el-switch>
          </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">  
        <el-button @click="quxiaotianjia3">取 消</el-button>
        <el-button type="primary" @click="quedingtianjia2">更新</el-button>
      </span>
    </el-dialog>

  </div>
</template>

<script>
import axios from 'axios';
import { Col } from 'element-ui';
// import { login } from "@/api/login";
// import { setToken } from "@/request/auth";

export default {
  name: "login",
  data() {
    return {
      isPC:this.isPCn(),
      tianjia:0,
      tianjiatype:0,
      image:null,
      img_src:"",
      taidengicon:new Image(),
      mengsuoicon:new Image(),
      chuanganqiicon:new Image(),
      kaiguanicon:new Image(),
      newicon:{
        devicename:"",
        type:0,
        switcher:0,
        light:0,
        temperature:0,
        dampness:0,
        msg:"",
        date:"",
        pointx:0.0,
        pointy:0.0,
      },
      form: {
        password: "",
        username: "",
        phonenumber:"",
        msg:"",
        picture:"",
        date:"",
        roomname:"",
        scenename:"",
        brbg:"/images/卧室.jpg",
        babg:"/images/卫生间.jpg",
        kibg:"/images/厨房.jpg",
        ketin:"/images/客厅.jpeg",
      },
      head_info:{
        token : this.$store.state.token,
        scenename:this.$store.state.scenename,
        roomname:this.$store.state.roomname,
      },
      checked: false,
      rules: {
        username: [
          { required: true, message: "请输入用户名", trigger: "blur" },
          { max: 15,min:1, message: "请介于6-15位", trigger: "blur" },
        ],
        password: [
          { required: true, message: "请输入密码", trigger: "blur" },
          { max: 15, min:1,message: "请介于6-15位", trigger: "blur" },
        ],
        phonenumber: [
          { required: true, message: "请输入电话号码", trigger: "blur" },
          { pattern: /^1[3|4|5|6|7|8|9][0-9]\d{8}$/, message: "非法的电话号码", trigger: "blur" },
        ],
      },
      tableData : [
      ],
      dialogVisible: false,
      dialogVisible2:false,
      dialogVisible3:false,
      dialogVisible4:false,
      index:-1,
    };
  },
  created(){
    this.taidengicon.src = this.$http.defaults.baseURL+"/images/台灯.png";
    this.kaiguanicon.src = this.$http.defaults.baseURL+"/images/开关.png";
    this.mengsuoicon.src = this.$http.defaults.baseURL+"/images/智能门锁.png";
    this.chuanganqiicon.src = this.$http.defaults.baseURL+"/images/一氧化碳传感器.png";
  },
  mounted() {
    var storage=window.localStorage;
    this.$store.state.token = storage.getItem("token");
    this.$store.state.type = parseInt(storage.getItem("type"));
    this.$store.state.roomname = storage.getItem("roomname");
    this.$store.state.scenename = storage.getItem("scenename");
    this.$store.state.form.nickname = storage.getItem("nickname");
    this.$store.state.form.id=storage.getItem("id"); 
    var myc = document.getElementById("mycanvas");
    if(this.isPC){

      myc.width="970";		// 注意：没有单位
      myc.height="490";
    }  
    
      this.$http.get('/devicelist',{
        params:{
          token : this.$store.state.token,
          scenename:this.$store.state.scenename,
          roomname:this.$store.state.roomname,
        }
      }).then(
        (res)=>{
          console.log(res.data);
            this.tableData=res.data;
            console.log(this.tableData);
            this.DrawIcon();
        }
      ).catch(
        (res)=>{
          console.log(res);
        }
      );
      this.$http.get('/devicelist_room',{
        params:{
          token : this.$store.state.token,
          scenename:this.$store.state.scenename,
          roomname:this.$store.state.roomname,
        }
      }).then(
        (res)=>{
          
           this.form.roomname = res.data.roomname;
           this.form.msg  = res.data.msg;
           this.form.date = res.data.date;
           this.form.picture = res.data.picture;
           var div = document.getElementById("bejing2");

          // 修改div的背景图片
          div.style.backgroundImage = "url("+ "http://localhost:8088"+this.form.picture+")";
           if(this.isPC)this.Draw();
           console.log(res.data);
            // console.log(this.tableData);
        }
      ).catch(
        (res)=>{
          console.log(res);
        }
      );
      
      console.log(this.form);
      // this.chuanganqiicon.onload=()=>{
      //   this.DrawIcon();
      // }
      if(this.isPC)this.DrawIcon();
      // ;
  },
  methods: {
    tuxinghua(){
      this.dialogVisible4 = true;
      this.$nextTick(() => {
        var div = document.getElementById("bejing2");

      
          // 修改div的背景图片
          div.style.backgroundImage = "url("+ "http://192.168.43.84:8088"+this.form.picture+")";
          var myc = document.getElementById("mycanvas");
          var ctx = myc.getContext("2d");
          // myc.width="1011";
          // myc.height="600";
          myc.style.backgroundColor = 'transparent';
          ctx.imageSmoothingEnabled = true;
          myc.width=div.clientWidth;
          myc.height = div.clientHeight;
          ctx.clearRect(0, 0, myc.width, myc.height);
          for(var j=0;j<this.tableData.length;j++){
            var i = this.tableData[j];
            console.log(i);
            if(i.type == 1){
              ctx.drawImage(this.taidengicon,myc.width*i.pointx-5,myc.height*i.pointy-5,10,10);
            }else if(i.type==2){
              ctx.drawImage(this.mengsuoicon,myc.width*i.pointx-5,myc.height*i.pointy-5,10,10);
            }else if(i.type==3){
              ctx.drawImage(this.chuanganqiicon,myc.width*i.pointx-5,myc.height*i.pointy-5,10,10);
            }else if(i.type == 4){
              ctx.drawImage(this.kaiguanicon,myc.width*i.pointx-5,myc.height*i.pointy-5,10,10);
            }
          }
          if(isPC)this.DrawIcon();
           if(isPC)this.Draw();
	    })
    },
    isPCn() {
            var userAgentInfo = navigator.userAgent;
            var Agents = ["Android", "iPhone",
                "SymbianOS", "Windows Phone",
                "iPad", "iPod"];
            var flag = true;
            for (var v = 0; v < Agents.length; v++) {
                if (userAgentInfo.indexOf(Agents[v]) > 0) {
                    flag = false;
                    break;
                }
            }
            return flag;
        },
    handlePreview(response, file, fileList){
      console.log(response);
      if(response.code=="200"){
        var div = document.getElementById("bejing2");
// 修改div的背景图片
        div.style.backgroundImage = "url("+ this.$http.defaults.baseURL+"/images/"+response.token+")";
        this.form.picture =this.$http.defaults.baseURL+"/images/"+response.token;
        alert("更新成功");
      }else{
        alert("更新失败");
      }
    },
    handleChange(file){
      console.log(file);
      const formData = new FormData();
      formData.append('file', file);
      const config = {
        headers: {
          'content-type': 'multipart/form-data'
        }
      };

      this.$http.post('/upload_pic', formData, config)
        .then(response => {
          // handle success
        })
        .catch(error => {
          // handle error
        });
    },
    shiyongbeijingmoban(){
          
      var div = document.getElementById("bejing2");
// 修改div的背景图片

      if(this.$store.state.type==1){
        div.style.backgroundImage = "url("+ "http://localhost:8088"+this.form.brbg+")";
        this.form.picture = this.form.brbg;
      }else if(this.$store.state.type==2){
        div.style.backgroundImage = "url("+ "http://localhost:8088"+this.form.kibg+")";
        this.form.picture = this.form.kibg;
      }else if(this.$store.state.type==3){
        div.style.backgroundImage = "url("+ "http://localhost:8088"+this.form.babg+")";
        this.form.picture = this.form.babg;

      }else if(this.$store.state.type==4){
        div.style.backgroundImage = "url("+ "http://localhost:8088"+this.form.ketin+")";
        this.form.picture = this.form.ketin;
        
      }else{
        alert("错误的场所");
      }
      //this.Draw();

      this.$http.get('/update_pic',{
        params:{
          token : this.$store.state.token,
          scenename:this.$store.state.scenename,
          roomname:this.$store.state.roomname,
          picture: this.form.picture,
        }
      }).then(
        (res)=>{
          if(res.data.code=="200"){
            alert("使用成功");
          }else{
            alert("使用失败");
          }
        }
      ).catch(
        (res)=>{
          console.log(res);
        }
      );

    },
    quxiaotianjia(){
      this.dialogVisible = false;
      this.tianjia=0;
    },
    quxiaotianjia2(){
      this.dialogVisible2 = false;
    },
    quxiaotianjia3(){
      this.dialogVisible3 = false;
    },
    quedingtianjia(){
      this.$http.post('/Scene_List/Room_List/Device',{
              token:this.$store.state.token,
              scenename:this.$store.state.scenename,
              roomname:this.$store.state.roomname,
              devicename:this.newicon.devicename,
              type:this.tianjiatype,
              switcher: this.newicon.switcher,
              light:this.newicon.light,
              temperature:this.newicon.temperature,
              dampness:this.newicon.dampness,
              msg:this.newicon.msg,
              date:this.newicon.date,
              pointx:this.newicon.pointx,
              pointy:this.newicon.pointy,
      }).then((res)=>{
        console.log(res);
        if(res.data.code=="200"){
          alert("Update succeed");
          this.dialogVisible = false;
          this.tianjia = 0;
          this.tableData.push({
              token:this.$store.state.token,
              scenename:this.$store.state.scenename,
              roomname:this.$store.state.roomname,
              devicename:this.newicon.devicename,
              type:this.tianjiatype,
              switcher: this.newicon.switcher,
              light:this.newicon.light,
              temperature:this.newicon.temperature,
              dampness:this.newicon.dampness,
              msg:this.newicon.msg,
              date:this.newicon.date,
              pointx:this.newicon.pointx,
              pointy:this.newicon.pointy,
              username:this.$store.state.token
          });
          this.DrawIcon();
        }else{
          alert("update error");
        }
      }).catch({

      });
      
    },
    quedingtianjia2(){
      this.$http.post('/Scene_List/Room_List/Device_update',{
              token:this.$store.state.token,
              scenename:this.$store.state.scenename,
              roomname:this.$store.state.roomname,
              devicename:this.newicon.devicename,
              type:this.tianjiatype,
              switcher: this.newicon.switcher,
              light:this.newicon.light,
              temperature:this.newicon.temperature,
              dampness:this.newicon.dampness,
              msg:this.newicon.msg,
              date:this.newicon.date,
              pointx:this.newicon.pointx,
              pointy:this.newicon.pointy,
      }).then((res)=>{
        console.log(res);
        if(res.data.code=="200"){
          alert("Update succeed");
          this.dialogVisible2 = false;
          this.tianjia = 0;
          //devicename=#{devicename},switcher=#{switcher},light=#{light},temperature=#{temperature},dampness=#{dampness},msg=#{msg},date=#{date}
          this.tableData[this.index].devicename = this.newicon.devicename;
          this.tableData[this.index].switcher = this.newicon.switcher;
          this.tableData[this.index].light = this.newicon.light;
          this.tableData[this.index].temperature = this.newicon.temperature;
          this.tableData[this.index].dampness = this.newicon.dampness;
          this.tableData[this.index].msg = this.newicon.msg;
          this.tableData[this.index].date = this.newicon.date;
          this.DrawIcon();
        }else{
          alert("update error");
        }
      }).catch((res)=>{
        // alert("主键重复，或其他特殊原因");
        });
    },
    handleEdit(index, row){
      this.newicon.devicename = row.devicename;
      this.tianjiatype = row.type;
      this.newicon.switcher = row.switcher,
      this.newicon.light = row.light,
      this.newicon.temperature = row.temperature,
      this.newicon.dampness = row.dampness,
      this.newicon.msg = row.msg,
      this.newicon.date = row.date;
      if(this.isPC){
        this.dialogVisible2 = true;
      }else{
        this.dialogVisible3 = true;
      }
      
      this.index = index;

    },
    DrawIcon(){
      console.log("drawicon被调用");
      var myc = document.getElementById("mycanvas");
      var ctx = myc.getContext("2d");
      ctx.imageSmoothingEnabled = true;
      myc.style.backgroundColor = 'transparent';
      ctx.clearRect(0, 0, myc.width, myc.height);
      for(var j=0;j<this.tableData.length;j++){
        var i = this.tableData[j];
        console.log(i);
        if(i.type == 1){
          ctx.drawImage(this.taidengicon,myc.width*i.pointx-15,myc.height*i.pointy-15,30,30);
        }else if(i.type==2){
          ctx.drawImage(this.mengsuoicon,myc.width*i.pointx-15,myc.height*i.pointy-15,30,30);
        }else if(i.type==3){
          ctx.drawImage(this.chuanganqiicon,myc.width*i.pointx-15,myc.height*i.pointy-15,30,30);
        }else if(i.type == 4){
          ctx.drawImage(this.kaiguanicon,myc.width*i.pointx-15,myc.height*i.pointy-15,30,30);
        }
      }

    },
    dianjihuamu(event){
      var x = event.offsetX;
      var y = event.offsetY;
      var myc = document.getElementById("mycanvas");
      var ctx = myc.getContext("2d");
      var img = new Image();
    // 输出点击位置的横纵坐标
      console.log(x, y);
      console.log(Math.floor(x)/myc.width);
      if(this.tianjia==1){
          this.dialogVisible = true;
          this.tianjia=0;
          this.newicon.pointx =Math.floor(x)/myc.width;
          this.newicon.pointy = Math.floor(y)/myc.height;
      }else{
        console.log(myc.width,myc.height);
        for(var j=0;j<this.tableData.length;j++){
          var i=this.tableData[j];
          console.log(i);
          console.log(i.pointx*myc.width-15);
          console.log(i.pointx*myc.width+15);
          console.log(i.pointy*myc.height-15);
          console.log(i.pointy*myc.height+15);
          if(x>=i.pointx*myc.width-30&&x<=i.pointx*myc.width+30&&y>=i.pointy*myc.height-30&&y<=i.pointy*myc.height+30){
            console.log("dainjidao"+i);
            if(i.type==1){
              this.$alert('设备名称:'+i.devicename+'<br>'+
                        '设备日期:'+i.date+'<br>'+
                        '设备类型:台灯<br>'+
                        '设备亮度'+i.light+'<br>'+
                        '开关状态：'+(i.switcher==0?'关':'开')+'<br>', 
                        '设备备注:'+i.msg,{
              confirmButtonText: '确定',
              dangerouslyUseHTMLString: true,
              callback: action => {
                
              }
              });
            }else if(i.type==2){
              console.log("dainjidao"+i);
              this.$alert('设备名称:'+i.devicename+'<br>'+
                        '设备日期:'+i.date+'<br>'+
                        '设备类型:门锁<br>'+
                        '开关状态：'+(i.switcher==0?'关':'开')+'<br>'+
                        '设备备注:'+i.msg, {
              confirmButtonText: '确定',
              dangerouslyUseHTMLString: true,
              callback: action => {
                
              }
              });
            }else if(i.type==3){
              this.$alert('设备名称:'+i.devicename+'<br>'+
                        '设备日期:'+i.date+'<br>'+
                        '设备类型:传感器<br>'+
                        '开关状态：'+(i.switcher==0?'关':'开')+'<br>'+
                        '温度:'+i.temperature+'<br>'+
                        '湿度:'+i.dampness+'<br>'+
                        '设备备注:'+i.msg, {
              confirmButtonText: '确定',
              dangerouslyUseHTMLString: true,
              callback: action => {
                
              }
              });
            }else if(i.type == 4){
              this.$alert('设备名称:'+i.devicename+'<br>'+
                        '设备日期:'+i.date+'<br>'+
                        '设备类型:开关<br>'+
                        '开关状态：'+(i.switcher==0?'关':'开')+'<br>'+
                        '设备备注:'+i.msg, 
                        {
              confirmButtonText: '确定',
              dangerouslyUseHTMLString: true,
              callback: action => {
                
              }
              });
            }
            break;
          }
        }
      }
    },
    taideng(){
      this.tianjia=1;
      this.tianjiatype=1;
      console.log("dainji1"+this.tianjia+this.tianjiatype);
    },
    mengsuo(){
      this.tianjia=1;
      this.tianjiatype=2;
    },
    chuanganqi(){
      this.tianjia=1;
      this.tianjiatype=3;
    },
    kaiguan(){
      this.tianjia=1;
      this.tianjiatype=4;
    },
    ret(){
      this.$router.push("/Scene_List/Room_List");
    },
    login(form) {
      console.log(this.form.password);
      console.log(this.form.phonenumber);
      console.log(this.form.username);
    },
    remenber(data){
      this.checked=data
      if(this.checked){
          localStorage.setItem("news",JSON.stringify(this.form))
      }else{
        localStorage.removeItem("news")
      }
    },
    forgetpas() {
      this.$message({
        type:"info",
        message:"暂不支持",
        showClose:true
      })
    },
    register() {
      
    },
    handleClose(done) {
        this.dialogVisible4 =false;
      },
    Draw(){
      var myc = document.getElementById("mycanvas");
      var ctx = myc.getContext("2d");
      // myc.width="1011";
      // myc.height="600";
      var img = new Image();
      myc.style.backgroundColor = 'transparent';
      this.DrawIcon();
      // img.src="https://img1.baidu.com/it/u=1628636888,511389021&fm=253&fmt=auto&app=138&f=JPEG?w=967&h=500";
      // img.onload=()=>{
      //   this.$set(this, "image", require("../assets/template/卧室.jpg"));
      //   ctx.clearRect(0,0,972,520); 
      //   ctx.beginPath();
      //   myc.style.backgroundColor = 'transparent';
      //   ctx.imageSmoothingEnabled = true;
      //   ctx.drawImage(img,0,0,200,200);
      //   ctx.stroke();
      // }
    },

    handleDelete(index, row) {
      console.log(index, row);
      this.$http.get('/one_device_delete',{
      params:{
          token : this.$store.state.token,
          scenename:this.$store.state.scenename,
          roomname:this.$store.state.roomname,
          devicename:row.devicename,
        }
      }).then(
        (res)=>{
          if(res.data.code=="200"){
            this.tableData.splice(index, 1);
            this.DrawIcon();
            alert("succeed");
          }else{
            alert("error");
          }
        }
      ).catch(
        (res)=>{
          console.log(res);
        }
      );
    }
  },
};
</script>

<style scoped>
#mycanvas{
  width:100%;
  height: 100%;
}
.left {
    width: 60%;
    height: 520px;
    background-color: rgb(94, 92, 92);
}

.left2 {
    width: 80vw;
    height: 30vh;
    background-color: rgb(94, 92, 92);
}
.Top{
  display: flex;
  flex-direction:row;
  padding: 30px;
  height: 750px;
  /* margin-top: 20px; */
  background-image: url("../assets/beijing.jpg");
  background-size: 100% 100%;
  background-position: center center;
  overflow: auto;
  background-repeat: no-repeat;
}
.Top2{
  height: 95vh;
  width: 93vw;
  padding: 3vw;
  /* margin-top: 20px; */
  background-image: url("../assets/beijing.jpg");
  background-size: 100% 100%;
  background-position: center center;
  overflow: auto;
  background-repeat: no-repeat;
}
.right{
    margin-left: 5%;
    width: 35%;
    padding-top: 30px;
    padding-left:20px ;
    padding-right:20px ;
    padding-bottom:15px ;
    display: flex;
    flex-direction: column;
    align-items: center;
    height: 550px;
    background-color: rgb(244, 239, 239);
    background-image: url("../../assets/images/login-bg.jpg");
    /* flex-direction: column; */
    justify-content: space-between;
    flex-wrap: wrap;
    align-content: space-between;
    position: absolute;
    left: 75%;
    transform: translateX(-50%);
    border-radius: 5px;
}
.right2{
    width: 80vw;
    padding-top: 30px;
    padding-left:20px ;
    padding-right:20px ;
    padding-bottom:15px ;
    display: flex;
    flex-direction: column;
    align-items: center;
    height: 550px;
    background-color: rgb(244, 239, 239);
    background-image: url("../../assets/images/login-bg.jpg");
    /* flex-direction: column; */
    justify-content: space-between;
    flex-wrap: wrap;
    align-content: space-between;
    border-radius: 5px;
}
.select{
  
  padding-top: 20px;
  padding-right: 20px;
  display: flex;
  flex-direction: row;
}
.bottom{
  width: 100%;
  border-radius: 5px;
  margin-top: 10px;
  background: url('../../assets/images/login-bg.jpg');
}
.roll{
  height: 90%;
  width: 100%;
  padding: 10px;
  border-radius: 5%;
}
.sub{
  width: 100%;
  height: 40px;
  display: flex;
  flex-direction: row;
  justify-content: space-evenly;
  /* margin-top:; */
}
#bejing2{
  height:100%;
  width:100%;
  border: 2px solid rgb(27, 26, 26);
  background-size: 100% 100%;
  background-position: center center;
  overflow: auto;
  background-repeat: no-repeat;
  /* background-image: url("https://img1.baidu.com/it/u=1628636888,511389021&fm=253&fmt=auto&app=138&f=JPEG?w=967&h=500"); */
}
i.fa-home {
  position: absolute;
  left: 0;
  top: 0;
}
</style>