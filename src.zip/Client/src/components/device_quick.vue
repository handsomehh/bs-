<template>
  <div>
    <div v-if="isPC" class="container">
    <div class="PersonTop">
      <div class="PersonTop_img">
        <img v-image-preview :src="avatar" />
      </div>
      <div class="PersonTop_text">
        <div class="user_text">
          <div class="user_name">
            <span> 昵称：{{ this.$store.state.form.nickname }} </span>
          </div>
          <div class="user-v" >
            <img src="../assets/logo.png" class="user-v-img" />
            <span class="user-v-font">智能家居管理员</span>
          </div>
          <div class="user_qianming">
            <span> 用户名：{{ this.$store.state.form.id }}</span>
          </div>
        </div>
        <div class="user_num">
        </div>
      </div>
    </div>
    <div class="person_body">
      <el-table
        :data="tableData"
        style="width: 100%"
        max-height="460">
        
        <el-table-column
          label="日期"
          width="200">
          <template slot-scope="scope">
            <i class="el-icon-time"></i>
            <span style="margin-left: 10px">{{ scope.row.date }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="场所名称"
          width="250">
          <template slot-scope="scope">

            <span style="margin-left: 10px">{{ scope.row.scenename }}</span>

          </template>
        </el-table-column>
        <el-table-column
          label="房间名称"
          width="250">
          <template slot-scope="scope">
            <span style="margin-left: 10px">{{ scope.row.roomname }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="设备名称"
          width="250">
          <template slot-scope="scope">
            <el-popover trigger="hover" placement="top">
              <p>备注: {{ scope.row.msg }}</p>
              <div slot="reference" class="name-wrapper">
                <el-tag size="medium">{{ scope.row.devicename }}</el-tag>
              </div>
            </el-popover>
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button
              size="mini"
              @click="handleEdit(scope.$index, scope.row)">快速进入</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div style="height:20px;"></div>
      <div class="tijiao">
        <el-button type="primary" size="large" round @click="ret">返回</el-button>
      </div>
    </div>
    <dia ref="dia" @flesh="update" />
    </div>

    <div v-if="!isPC" class="container2">
    <div class="person_body2">
      <el-table
        :data="tableData"
        style="width: 100%"
        max-height="460">
        
        <el-table-column
          label="日期"
          width="80">
          <template slot-scope="scope">
            <i class="el-icon-time"></i>
            <span style="margin-left: 10px">{{ scope.row.date }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="场所名称"
          width="70">
          <template slot-scope="scope">

            <span style="margin-left: 10px">{{ scope.row.scenename }}</span>

          </template>
        </el-table-column>
        <el-table-column
          label="房间名称"
          width="80">
          <template slot-scope="scope">
            <span style="margin-left: 10px">{{ scope.row.roomname }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="设备名称"
          width="80">
          <template slot-scope="scope">
            <el-popover trigger="hover" placement="top">
              <p>备注: {{ scope.row.msg }}</p>
              <div slot="reference" class="name-wrapper">
                <el-tag size="medium">{{ scope.row.devicename }}</el-tag>
              </div>
            </el-popover>
          </template>
        </el-table-column>
      </el-table>
      <div style="height:20px;"></div>
      <div class="tijiao">
        <el-button type="primary" size="large" round @click="ret">返回</el-button>
      </div>
    </div>
    <dia ref="dia" @flesh="update" />
    </div>
  </div>
</template>

<script>
// import { userInfo } from "@/api/user";
// import {
//   myFollow,
//   addFollow,
//   deleteFollow,
//   followAndFanCount,
// } from "@/api/follow.js";
// import { mygoodCount } from "@/api/good";
import PersonalDia from "./PersonalDia.vue";
import { mapState } from 'vuex';
import dia from '../tools/roomDia.vue';
import axios from 'axios';
export default {
  components: { PersonalDia,dia },
  name: "Personal",
  // inject: ["reload"],
  computed:mapState(
    ['token']
  ),
  data() {
    return {
      isPC: this.isPCNot(),
      form2: {
        date:"",
        scenename:"",
        msg:"",
        index:-1,
      },
      rules2: {
        scenename: [
          { required: true, message: "请输入房间名", trigger: "blur" },
        ],
      },
      avatar: "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fpic1.zhimg.com%2Fv2-2d6a27d0d18415ccc81fb3dc75f03ac8_r.jpg%3Fsource%3D1940ef5c&refer=http%3A%2F%2Fpic1.zhimg.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1672987373&t=53d5d88694504dfe257d320cb9fba19d",
      nickname: "111",
      v: 1,
      design: "111",
      followCounts: "111",
      fanCounts: "111",
      goodCounts: "111",
      isfollow: true,
      followData: {
        fanId: "11",
        followId: "11",
      },
      isfollowid: [],
      s_list:[
        {id:1,name:2},
        {id:2,name:3},
      ],
      tableData: [
      ],
      dialogVisible : false,
    };
  },
  mounted() {
    // this.load();
    var storage=window.localStorage;
    this.$store.state.token = storage.getItem("token");
    this.$store.state.type = parseInt(storage.getItem("type"));
    this.$store.state.roomname = storage.getItem("roomname");
    this.$store.state.scenename = storage.getItem("scenename");
    this.$store.state.form.nickname = storage.getItem("nickname");
    this.$store.state.form.id=storage.getItem("id");   
    this.$http.get('/alldevice',{
        params:{
          token : this.$store.state.token,
        }
      }).then(
        (res)=>{
          console.log(res.data);
            this.tableData=res.data;
            console.log(this.tableData);
        }
      ).catch(
        (res)=>{
          console.log(res);
        }
      );
  },
  watch: {
    $route(to, from) {
      if (to.path == `/newsuser/personal/${this.$store.state.id}`) {
        this.reload();
      } else if (to.path == `/newsuser/personal/${this.$route.params.id}`) {
        this.reload();
      }
    },
  },
  methods: {
    isPCNot() {
            var userAgentInfo = navigator.userAgent;
            var Agents = ["Android", "iPhone",
                "SymbianOS", "Windows Phone",
                "iPad", "iPod"];
            var flag = true;
            for (var v = 0; v < Agents.length; v++) {
                if (userAgentInfo.indexOf(Agents[v]) > 0) {
                    flag = false;
                    break;
                }
            }
            return flag;
        },
    update(){
      this.$http.get('/room',{
          params:{
            token : this.$store.state.token,
            type : this.$store.state.type,
          }
        }).then(
          (res)=>{
            console.log(res.data);
              this.tableData=res.data;
              console.log(this.tableData);
          }
        ).catch(
          (res)=>{
            console.log(res);
          }
        );
    },
    xingjian(){
      this.$refs.dia.open();
    },
    Bedroom(){
      console.log("Bedroom")
      this.$router.push("/Bedroom");
    },
    ret(){
      if(this.isPC){
        this.$router.push("/person");
      }else{
        this.$router.push("/person_mob");
      }
      
    },
    load() {
      userInfo(this.$route.params.id)
        .then((res) => {
          console.log(res);
          this.avatar = res.data.avatar;
          this.nickname = res.data.nickname;
          this.v = res.data.v;
          this.design = res.data.design;
        })
        .catch((err) => {
          console.log(err);
        });

      myFollow(this.$store.state.id)
        .then((res) => {
          res.data.forEach((res) => {
            this.isfollowid.push(res.id);
          });
        })
        .catch((err) => {
          console.log(err);
        });

      followAndFanCount(this.$route.params.id)
        .then((res) => {
          this.followCounts = res.data.followCounts;
          this.fanCounts = res.data.fanCounts;
        })
        .catch((err) => {
          console.log(err);
        });

      mygoodCount(this.$route.params.id)
        .then((res) => {
          this.goodCounts = res.data.goodCounts;
        })
        .catch((err) => {
          console.log(err);
        });
    },
    myfan() {
      this.$router.push({
        path: `/newsuser/personal/myfan/${this.$route.params.id}`,
      });
    },
    myfollow() {
      this.$router.push({
      path:`/newsuser/personal/myfollow/${this.$route.params.id}`,
      });
    },
    follow() {
      if (!this.$store.state.id) {
        this.$message({
          showClose: true,
          message: "请登录后再进行操作哦",
          type: "warning",
        });
      } else {
        this.followData.followId = this.$route.params.id;
        this.followData.fanId = this.$store.state.id;
        if (this.isfollowid.indexOf(this.followData.followId) > -1) {
          this.isfollow = true;
        } else {
          this.isfollow = false;
        }
        if (this.isfollow) {
          deleteFollow(this.followData)
            .then((res) => {
              this.isfollow = false;
              this.$message({
                showClose: true,
                message: "已取消关注",
                type: "success",
              });
              this.reload();
            })
            .catch((err) => {
              console.log(err);
            });
        } else if (!this.isfollow) {
          addFollow(this.followData)
            .then((res) => {
              this.isfollow = true;
              this.$message({
                showClose: true,
                message: "已成功关注",
                type: "success",
              });
              this.reload();
            })
            .catch((err) => {
              console.log(err);
            });
        }
      }
    },
    edit() {
      this.$refs.dia.open();
    },
    submit() {
      this.$http.post('/room_update',{
        token:this.$store.state.token,
        scenename:this.form2.scenename,
        msg:this.form2.msg,
        date:this.form2.date,
      }).then((res)=>{
        console.log(res);
        if(res.data.code=="200"){
          
          this.dialogVisible = false;
          // Object.assign(this.$store.state.form, this.form);
          this.tableData[this.form2.index].date = this.form2.date;
          this.tableData[this.form2.index].msg = this.form2.msg;
          alert("Update succeed");
        }else{
          alert("update error");
        }
      }).catch((res)=>{
        alert("update error");
        })
      // updateUser(this.form)
      //   .then((res) => {
      //     console.log(res);
      //     this.dialogVisible = false;
      //     this.$emit("flesh");
      //   })
      //   .catch((err) => {
      //     console.log(err);
      //   });
    },
    handleEdit(index, row) {
        console.log(index, row);
        this.$store.state.roomname = row.roomname;
        this.$store.state.scenename = row.scenename;
        var storage=window.localStorage;
              storage.setItem("token",this.$store.state.token);
              storage.setItem("type",this.$store.state.type);
              storage.setItem("roomname",this.$store.state.roomname);
              storage.setItem("scenename",this.$store.state.scenename);
              storage.setItem("nickname",this.$store.state.form.nickname);
              storage.setItem("id",this.$store.state.form.id);            
        this.$router.push("/Scene_List/Room_List/Device");
      },
      handleClose() {
      this.dialogVisible = false;
      
    },
      xiugai(index, row){
        this.dialogVisible = true;
        this.form2.date = row.date;
        this.form2.msg = row.msg;
        this.form2.scenename = row.scenename;
        this.form2.index = index;
      },
      handleDelete(index, row) {
        console.log(index, row);
        this.$http.get('/roomdelete',{
        params:{
            token : this.$store.state.token,
            type : this.$store.state.type,
            scenename:row.scenename,
          }
        }).then(
          (res)=>{
            if(res.data.code=="200"){
              this.tableData.splice(index, 1);
              alert("succeed");
            }else{
              alert("error");
            }
          }
        ).catch(
          (res)=>{
            console.log(res);
          }
        );
      },
  },
};
</script>

<style scoped>
.me-video-player {
  background-color: transparent;
  width: 100%;
  height: 100%;
  object-fit: fill;
  display: block;
  position: fixed;
  left: 0;
  z-index: 0;
  top: 0;
}
.PersonTop {
  width: 70%;
  height: 190px;
  padding-top: 10px;
  padding-left: 20px;
  background-color: rgba(212, 205, 205, 0.893);
  background: url('../../assets/images/login-bg.jpg');
  margin-top: 10px;
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
  border-radius: 5px;
}

.PersonTop_img {
  width: 150px;
  height: 120px;
  background-color: #8c939d;
  margin-right: 24px;
  margin-left: 20px;
  overflow: hidden;
  border-radius: 20px;
}

.PersonTop_img img {
  width: 100%;
  height: 100%;
  border-radius: 20px;
}

.PersonTop_text {
  height: 120px;
  width: 880px;
  display: flex;
}

.user_text {
  width: 20%;
  height: 100%;
  line-height: 30px;
}

.user_name {
  font-weight: bold;
  font-size: larger;
  color: rgb(190, 187, 187);
}
.user-v {
  margin-bottom: -5px;
}
.user-v-img {
  width: 15px;
  height: 15px;
}
.user-v-font {
  font-size: 15px;
  color: #00c3ff;
}
.user_qianming {
  font-size: 14px;
  color: #999;
}

.user_num {
  width: 70%;
  height: 100%;
  display: flex;
  align-items: center;
  flex-direction: row-reverse;
}

.user_num > div {
  text-align: center;
  border-right: 1px dotted #999;
  box-sizing: border-box;
  width: 80px;
  height: 40px;
  line-height: 20px;
}

.num_text {
  color: #999;
}

.num_number {
  font-size: 20px;
  color: #333;
}
.el-menu-item>span {
  font-size: 16px;
  color: #999;
}

/*下面部分样式*/
.person_body {
  width: 70%;
  margin-top: 230px;
  padding: 10px;
  padding-top: 30px;
  padding-left:20px ;
  padding-right:20px ;
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 500px;
  background-color: rgb(244, 239, 239);
  /* flex-direction: column; */
  justify-content: space-between;
  flex-wrap: wrap;
  align-content: space-between;
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  border-radius: 5px;
}
.person_body2 {
  width: 85%;

  padding: 10px;
  padding-top: 30px;
  padding-left:10px ;
  padding-right:10px ;
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 80vh;
  background-color: rgb(244, 239, 239);
  /* flex-direction: column; */
  justify-content: space-between;
  flex-wrap: wrap;
  align-content: space-between;
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  border-radius: 5px;
}
.box1 {
        border: 2px solid rgb(153, 150, 150);
        border-radius: 5px;
        box-sizing: border-box;
        background-color: rgb(148, 44, 44);
        /* calc为CSS3内容 */
        width: calc(50% - 15px);
        height: calc(50% - 15px);
        background-image: url("../assets/template/卧室控件.jpg");
        background-size: 100% 100%;
        background-position: center center;
        overflow: auto;
        background-repeat: no-repeat;
 }
 .ziti{
  font-family:Arial, Helvetica, sans-serif ;
 }
 .zhanwei{
  width: 100%;
  height: 70%;
 }
 .box2 {
  border: 2px solid rgb(153, 150, 150);
        border-radius: 5px;
        box-sizing: border-box;
        background-color: rgb(148, 44, 44);
        /* calc为CSS3内容 */
        width: calc(50% - 15px);
        height: calc(50% - 15px);
        background-image: url("../assets/template/厨房控件.jpg");
        background-size: 100% 100%;
        background-position: center center;
        overflow: auto;
        background-repeat: no-repeat;
 }
 .box3 {
  border: 2px solid rgb(153, 150, 150);
        border-radius: 5px;
        box-sizing: border-box;
        background-color: rgb(148, 44, 44);
        /* calc为CSS3内容 */
        width: calc(50% - 15px);
        height: calc(50% - 15px);
        background-image: url("../assets/template/卫生间控件.jpg");
        background-size: 100% 100%;
        background-position: center center;
        overflow: auto;
        background-repeat: no-repeat;
 }
 .box4 {
  border: 2px solid rgb(153, 150, 150);
        border-radius: 5px;
        box-sizing: border-box;
        background-color: rgb(148, 44, 44);
        /* calc为CSS3内容 */
        width: calc(50% - 15px);
        height: calc(50% - 15px);
        background-image: url("../assets/template/客厅控件.jpg");
        background-size: 100% 100%;
        background-position: center center;
        overflow: auto;
        background-repeat: no-repeat;
 }
.person_body_left {
  width: 27%;
  height: 600px;
  border-radius: 5px;
  margin-right: 3%;
  text-align: center;
}

.person_body_list {
  width: 100%;
  height: 50px;
  margin-top: 25px;
  font-size: 22px;
  border-bottom: 1px solid #f0f0f0;
  background-image: -webkit-linear-gradient(
    left,
    rgb(42, 134, 141),
    #e9e625dc 20%,
    #3498db 40%,
    #e74c3c 60%,
    #09ff009a 80%,
    rgba(82, 196, 204, 0.281) 100%
  );
  -webkit-text-fill-color: transparent;
  -webkit-background-clip: text;
  -webkit-background-size: 200% 100%;
  -webkit-animation: masked-animation 4s linear infinite;
}

.el-menu-item {
  margin-top: 22px;
}

.person_body_right {
  width: 70%;
  /* height: 500px; */
  border-radius: 5px;
  background-color: white;
}

.box-card {
  height: 500px;
}

/*ui样式*/
.el-button {
  width: 84px;
}

.container{
  width:100%;
  height: 800px;
  background-image: url("../assets/beijing.jpg");
  background-size: 100% 100%;
  background-position: center center;
  overflow: auto;
  background-repeat: no-repeat;
}
.container2{
  width:100%;
  height: 100vh;
  background-image: url("../assets/beijing.jpg");
  background-size: 100% 100%;
  background-position: center center;
  overflow: auto;
  background-repeat: no-repeat;
  padding-top: 10px;
}
.hcqStyle1{color:hsl(184,80%,25%);text-shadow:0 0 1px currentColor,/*highlight*/-1px -1px 1px hsl(184,80%,50%),0 -1px 1px hsl(184,80%,55%),1px -1px 1px hsl(184,80%,50%),/*light shadow*/1px 1px 1px hsl(184,80%,10%),0 1px 1px hsl(184,80%,10%),-1px 1px 1px hsl(184,80%,10%),/*outline*/-2px -2px 1px hsl(184,80%,15%),-1px -2px 1px hsl(184,80%,15%),0 -2px 1px hsl(184,80%,15%),1px -2px 1px hsl(184,80%,15%),2px -2px 1px hsl(184,80%,15%),2px -1px 1px hsl(184,80%,15%),2px 0 1px hsl(184,80%,15%),2px 1px 1px hsl(184,80%,15%),-2px 0 1px hsl(184,80%,15%),-2px -1px 1px hsl(184,80%,15%),-2px 1px 1px hsl(184,80%,15%),/*dark shadow*/2px 2px 2px hsl(184,80%,5%),1px 2px 2px hsl(184,80%,5%),0 2px 2px hsl(184,80%,5%),-1px 2px 2px hsl(184,80%,5%),-2px 2px 2px hsl(184,80%,5%)}
    
.tijiao{
  display: flex;
  flex-direction: rows;
  justify-content: space-evenly
}
</style>