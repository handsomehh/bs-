<template>
  <div>
      <el-dialog
  title="修改个人信息"
  :visible.sync="dialogVisible"
  width="60%"
  :before-close="handleClose">
  <el-form :model="form" :rules="rules" ref="form" label-width="150px">
      <div class="updateinfo">
  <div class="left">
      <el-form-item label="头像" prop="avatar">
            <img style="width:150px;height:110px" src="../assets/touxiang.jpg">
          </el-form-item>

          <el-form-item label="昵称" prop="nickname">
            <el-input maxlength="20" v-model="form.nickname"></el-input>
          </el-form-item>
          <el-form-item label="年龄" prop="age">
            <el-input maxlength="20" v-model="form.age"></el-input>
          </el-form-item>
          <el-form-item label="性别" prop="sex">
            <el-switch
              v-model="form.sex"
              active-color="#13ce66"
              inactive-color="#ff4949"
              active-text="男"
              inactive-text="女"
              :active-value= "1"
               :inactive-value= "0"
            >
            </el-switch>
          </el-form-item>
          <el-form-item label="邮箱" prop="email">
            <el-input maxlength="20" v-model="form.email"></el-input>
          </el-form-item>
  </div>
  <div class="right">
      <el-form-item label="用户名" prop="id">
            <el-input maxlength="10" v-model="form.id" disabled></el-input>
          </el-form-item>
          <el-form-item label="密码" prop="account">
            <el-input maxlength="10" v-model="form.password" disabled></el-input>
          </el-form-item>
          <el-form-item label="地区" prop="area">
            <el-input maxlength="20" v-model="form.area"></el-input>
          </el-form-item>
          <el-form-item label="兴趣爱好" prop="hobby">
            <el-input maxlength="20" v-model="form.hobby"></el-input>
          </el-form-item>
          <el-form-item label="职业" prop="work">
            <el-input maxlength="20" v-model="form.work"></el-input>
          </el-form-item>
                    <el-form-item maxlength="20" label="个性签名" prop="design">
            <el-input v-model="form.design"></el-input>
          </el-form-item>
          <el-form-item label="手机号码" prop="mobilePhoneNumber">
            <el-input maxlength="20" v-model="form.phone"></el-input>
          </el-form-item>
  </div>
  </div>
  </el-form>
  <span slot="footer" class="dialog-footer">
    <el-button @click="handleClose">取 消</el-button>
    <el-button type="primary" @click="submit">提 交</el-button>
  </span>
</el-dialog>
  </div>
</template>

<script>
// import { userInfo, updateUser } from "@/api/user.js";

export default {
  name: "PersonalDia",
  data() {
    return {
      dialogVisible: false,
      form: {
        avatar: "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fpic1.zhimg.com%2Fv2-2d6a27d0d18415ccc81fb3dc75f03ac8_r.jpg%3Fsource%3D1940ef5c&refer=http%3A%2F%2Fpic1.zhimg.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1672987373&t=53d5d88694504dfe257d320cb9fba19d",
        password: "",
        nickname: "",
        age: Number,
        email: "",
        phone: "",
        sex: Number,
        id: "",
        area: "",
        hobby: "",
        work: "",
        design: "",
      },
      rules: {
      },
    };
  },
  mounted() {
    var storage=window.localStorage;
    this.$store.state.token = storage.getItem("token");
    this.$store.state.type = parseInt(storage.getItem("type"));
    this.$store.state.roomname = storage.getItem("roomname");
    this.$store.state.scenename = storage.getItem("scenename");
    this.$store.state.form.nickname = storage.getItem("nickname");
    this.$store.state.form.id=storage.getItem("id");   
    this.$http.get('/person/details',{
        params:{
          token : this.$store.state.token,
        }
      }).then(
        (res)=>{
          console.log(res);
          if(res.data.code=="200"){
            Object.assign(this.form, res.data);
            Object.assign(this.$store.state.form, res.data);
          }else{
            alert("请求失败，错误代码"+res.data.code);
          }
        }
      ).catch(
        (res)=>{
          console.log(res);
        }
      );
  },
  methods: {
    open() {
      this.dialogVisible = true;
      console.log(this.data);
    },
    load() {
      // userInfo(this.$store.state.id)
      //   .then((res) => {
      //     console.log(res);
      //     Object.assign(this.form, res.data);
      //   })
      //   .catch((err) => {
      //     console.log(err);
      //   });
    },
    submit() {
      this.$http.post('/person/details',{
              avatar:this.form.avatar,
              password:this.form.password,
              nickname:this.form.nickname,
              age:this.form.age,
              email:this.form.email,
              phone: this.form.phone,
              sex:this.form.sex ,
              id:this.form.id,
              area:this.form.area,
              hobby:this.form.hobby,
              work:this.form.work,
              token:this.$store.state.token,
      }).then((res)=>{
        console.log(res);
        if(res.data.code=="200"){
          alert("Update succeed");
          this.dialogVisible = false;
          Object.assign(this.$store.state.form, this.form);
          var storage=window.localStorage;
          storage.setItem("token",this.$store.state.token);
          storage.setItem("type",this.$store.state.type);
          storage.setItem("roomname",this.$store.state.roomname);
          storage.setItem("scenename",this.$store.state.scenename);
          storage.setItem("nickname",this.$store.state.form.nickname);
          storage.setItem("id",this.$store.state.form.id);            
          this.$emit("flesh");
        }else{
          alert("update error");
        }
      }).catch({

      })
      // updateUser(this.form)
      //   .then((res) => {
      //     console.log(res);
      //     this.dialogVisible = false;
      //     this.$emit("flesh");
      //   })
      //   .catch((err) => {
      //     console.log(err);
      //   });
    },
    handleClose() {
      this.dialogVisible = false;
      this.$emit("flesh");
    },
  },
};
</script>

<style scoped>
.updateinfo {
  height: 350px;
  overflow: auto;
}
.left {
  /* width: 330px; */
  float: left;
}
.right {
  overflow: hidden;
}
</style>