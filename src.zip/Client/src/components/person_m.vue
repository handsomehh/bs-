<template>
  <div>

    <div class="container">
    <div class="PersonTop">
      <div class="PersonTop_img">
        <img v-image-preview :src="avatar" />
      </div>
      <div class="PersonTop_text">
        <div class="user_text">
          <div class="user_name">
            <span> 昵称：{{ this.$store.state.form.nickname }} </span>
          </div>
          <div class="user-v" >
            
          </div>
          <div class="user_qianming">
            
          </div>
          <div class="user_anniu">
            
          </div>
        </div>
        <div class="user_num">
          <div style="cursor: pointer" >
            <div class="num_number">{{ followCounts }}</div>
            <span class="num_text">设备数</span>
          </div>
          <div style="cursor: pointer" >
            <div class="num_number">{{ fanCounts }}</div>
            <span class="num_text">场所数</span>
          </div>
        </div>
      </div>
    </div>
    <div class="person_body">
      <div class="box1" @click="Bedroom">
        
        <h1 class='hcqFont hcqStyle1'>My Bedroom</h1>
    </div>
      <div class="box2" @click="Kitchen">
        
        <h1 class='hcqFont hcqStyle1' >My Kitchen</h1>
      </div>
      <div class="box3" @click="Bathroom">
       	
        <h1 class='hcqFont hcqStyle1' >My Bathroom</h1>
      </div>
      <div class="box4" @click="Parlor">
       	
        <h1 class='hcqFont hcqStyle1' >My parlor</h1>
      </div>
    </div>
    <!-- <div class="person_body"> -->
      <!-- <div class="person_body_left">
        <el-card class="box-card" :body-style="{ padding: '0px' }">
          <div slot="header" class="clearfix">
            <span class="person_body_list" style="border-bottom: none"
              >个人中心</span
            >
          </div> -->
          <!-- <div
            class="person_body_list"
            v-for="(item, index) in person_body_list"
            :key="index"
          >
            <router-link :to="{ name: item.name, params: item.params }">{{
              item.label
            }}</router-link>
          </div> -->
          <!-- <el-menu
            router
            active-text-color="#00c3ff"
            class="el-menu-vertical-demo"
          >
            <el-menu-item
              index="info"
              :route="{ name: 'info', params: $route.params.id }"
            >
              <i class="el-icon-user"></i>
              <span slot="title">个人简介</span>
            </el-menu-item>
            <el-menu-item
              index="myarticle"
              :route="{ name: 'myarticle', params: $route.params.id }"
            >
              <i class="el-icon-edit-outline"></i>
              <span slot="title">发帖</span>
            </el-menu-item>
            <el-menu-item
              index="mycollect"
              :route="{ name: 'mycollect', params: $route.params.id }"
            >
              <i class="el-icon-document"></i>
              <span slot="title">收藏</span>
            </el-menu-item>
            <el-menu-item
              index="myfan"
              :route="{ name: 'myfan', params: $route.params.id }"
            >
              <i class="el-icon-tableware"></i>
              <span slot="title">粉丝</span>
            </el-menu-item>
            <el-menu-item
              index="myfollow"
              :route="{ name: 'myfollow', params: $route.params.id }"
            >
              <i class="el-icon-circle-plus-outline"></i>
              <span slot="title">关注</span>
            </el-menu-item>
          </el-menu>
        </el-card>
      </div>
      <div class="person_body_right">
        <router-view></router-view>
      </div>
    </div> -->
    <!-- <personal-dia ref="dia" @flesh="reload" /> -->
    <PersonalDia ref="dia" @flesh="reload" />
    </div>
  </div>
</template>

<script>
// import { userInfo } from "@/api/user";
// import {
//   myFollow,
//   addFollow,
//   deleteFollow,
//   followAndFanCount,
// } from "@/api/follow.js";
// import { mygoodCount } from "@/api/good";
import PersonalDia from "./PersonalDia.vue";
import { mapState } from 'vuex';
import axios from 'axios';
export default {
  components: { PersonalDia },
  name: "Personal",
  // inject: ["reload"],
  computed:mapState(
    ['token']
  ),
  data() {
    return {
      avatar: "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fpic1.zhimg.com%2Fv2-2d6a27d0d18415ccc81fb3dc75f03ac8_r.jpg%3Fsource%3D1940ef5c&refer=http%3A%2F%2Fpic1.zhimg.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1672987373&t=53d5d88694504dfe257d320cb9fba19d",
      nickname: "111",
      v: 1,
      design: "111",
      followCounts: "0",
      fanCounts: "0",
      goodCounts: "111",
      isfollow: true,
      followData: {
        fanId: "11",
        followId: "11",
      },
      isfollowid: [],
      s_list:[
        {id:1,name:2},
        {id:2,name:3},
      ],
      tableData: [{
          date: '2016-05-02',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄'
        }, {
          date: '2016-05-04',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1517 弄'
        }, {
          date: '2016-05-01',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1519 弄'
        }, {
          date: '2016-05-03',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1516 弄'
        }]
    };
  },
  created(){
    // localStorage.getItem("userMsg") && this.$store.replaceState(Object.assign(this.$store.state,JSON.parse(localStorage.getItem("userMsg"))));
  },
  mounted() {
    var storage=window.localStorage;
    this.$store.state.token = storage.getItem("token");
    this.$store.state.type = parseInt(storage.getItem("type"));
    this.$store.state.roomname = storage.getItem("roomname");
    this.$store.state.scenename = storage.getItem("scenename");
    this.$store.state.form.nickname = storage.getItem("nickname");
    this.$store.state.form.id=storage.getItem("id");   
    this.$http.get('/changjingshuliang',{
        params:{
          token : this.$store.state.token,
        }
      }).then(
        (res)=>{
          if(res.data.code=="200"){
            this.fanCounts = res.data.number;
          }else{
            alert("场景总数拉取失败");
          }
        }
      ).catch(
        (res)=>{
          console.log(res);
        }
      );
    this.$http.get('/shebeishuliang',{
        params:{
          token : this.$store.state.token,
        }
      }).then(
        (res)=>{
          if(res.data.code=="200"){
            this.followCounts = res.data.number;
          }else{
            alert("场景总数拉取失败");
          }
        }
      ).catch(
        (res)=>{
          console.log(res);
        }
      );
    this.load();
  },
  watch: {
    $route(to, from) {
      if (to.path == `/newsuser/personal/${this.$store.state.id}`) {
        this.reload();
      } else if (to.path == `/newsuser/personal/${this.$route.params.id}`) {
        this.reload();
      }
    },
  },
  methods: {
   Bedroom(){
      console.log("Bedroom")
      this.$store.state.type=1;
      var storage=window.localStorage;
              storage.setItem("token",this.$store.state.token);
              storage.setItem("type",this.$store.state.type);
              storage.setItem("roomname",this.$store.state.roomname);
              storage.setItem("scenename",this.$store.state.scenename);
              storage.setItem("nickname",this.$store.state.form.nickname);
              storage.setItem("id",this.$store.state.form.id);            
      this.$router.push("/Scene_List");
    },
    Kitchen(){
      console.log("Kitchen")
      this.$store.state.type=2;
      var storage=window.localStorage;
              storage.setItem("token",this.$store.state.token);
              storage.setItem("type",this.$store.state.type);
              storage.setItem("roomname",this.$store.state.roomname);
              storage.setItem("scenename",this.$store.state.scenename);
              storage.setItem("nickname",this.$store.state.form.nickname);
              storage.setItem("id",this.$store.state.form.id);            
      this.$router.push("/Scene_List");
    },
    Bathroom(){
      console.log("Bathroom")
      this.$store.state.type=3;
      var storage=window.localStorage;
              storage.setItem("token",this.$store.state.token);
              storage.setItem("type",this.$store.state.type);
              storage.setItem("roomname",this.$store.state.roomname);
              storage.setItem("scenename",this.$store.state.scenename);
              storage.setItem("nickname",this.$store.state.form.nickname);
              storage.setItem("id",this.$store.state.form.id);            
      this.$router.push("/Scene_List");
    },
    Parlor(){
      console.log("Parlor")
      
      this.$store.state.type=4;
      var storage=window.localStorage;
              storage.setItem("token",this.$store.state.token);
              storage.setItem("type",this.$store.state.type);
              storage.setItem("roomname",this.$store.state.roomname);
              storage.setItem("scenename",this.$store.state.scenename);
              storage.setItem("nickname",this.$store.state.form.nickname);
              storage.setItem("id",this.$store.state.form.id);    
      this.$router.push("/Scene_List");
    },
    load() {
      userInfo(this.$route.params.id)
        .then((res) => {
          console.log(res);
          this.avatar = res.data.avatar;
          this.nickname = res.data.nickname;
          this.v = res.data.v;
          this.design = res.data.design;
        })
        .catch((err) => {
          console.log(err);
        });

      myFollow(this.$store.state.id)
        .then((res) => {
          res.data.forEach((res) => {
            this.isfollowid.push(res.id);
          });
        })
        .catch((err) => {
          console.log(err);
        });

      followAndFanCount(this.$route.params.id)
        .then((res) => {
          this.followCounts = res.data.followCounts;
          this.fanCounts = res.data.fanCounts;
        })
        .catch((err) => {
          console.log(err);
        });

      mygoodCount(this.$route.params.id)
        .then((res) => {
          this.goodCounts = res.data.goodCounts;
        })
        .catch((err) => {
          console.log(err);
        });
    },
    myfan() {
      this.$router.push({
        path: `/newsuser/personal/myfan/${this.$route.params.id}`,
      });
    },
    myfollow() {
      this.$router.push({
      path:`/newsuser/personal/myfollow/${this.$route.params.id}`,
      });
    },
    follow() {
      if (!this.$store.state.id) {
        this.$message({
          showClose: true,
          message: "请登录后再进行操作哦",
          type: "warning",
        });
      } else {
        this.followData.followId = this.$route.params.id;
        this.followData.fanId = this.$store.state.id;
        if (this.isfollowid.indexOf(this.followData.followId) > -1) {
          this.isfollow = true;
        } else {
          this.isfollow = false;
        }
        if (this.isfollow) {
          deleteFollow(this.followData)
            .then((res) => {
              this.isfollow = false;
              this.$message({
                showClose: true,
                message: "已取消关注",
                type: "success",
              });
              this.reload();
            })
            .catch((err) => {
              console.log(err);
            });
        } else if (!this.isfollow) {
          addFollow(this.followData)
            .then((res) => {
              this.isfollow = true;
              this.$message({
                showClose: true,
                message: "已成功关注",
                type: "success",
              });
              this.reload();
            })
            .catch((err) => {
              console.log(err);
            });
        }
      }
    },
    edit() {
      this.$refs.dia.open();
    },
    handleEdit(index, row) {
        console.log(index, row);
      },
      handleDelete(index, row) {
        console.log(index, row);
      },
  },
};
</script>

<style scoped>
.PersonTop {
  width: 92vw;
  height: 10vh;
  padding-top: 3vh;
  padding-bottom: 3vh;
  padding-left: 3vw;
  background-color: rgba(212, 205, 205, 0.893);
  background: url('../../assets/images/login-bg.jpg');
  margin-top: 2vh;
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
  border-radius: 5px;
}

.PersonTop_img {
  width: 20%;
  height: 100%;
  background-color: #8c939d;
  margin-right: 1vw;
  margin-left: 1vw;
  overflow: hidden;
  border-radius: 5%;
}

.PersonTop_img img {
  width: 100%;
  height: 100%;
  border-radius: 20px;
}

.PersonTop_text {
  height: 100%;
  width: 70%;
  display: flex;
}

.user_text {
  padding-top:2vh;
  width: 72%;
  height: 100%;
  line-height: 3vh;
}

.user_name {
  font-weight: bold;
  font-size: medium;
  color: rgb(190, 187, 187);
}
.user-v {
  margin-bottom: -5px;
}
.user-v-img {
  width: 15px;
  height: 15px;
}
.user-v-font {
  font-size: 15px;
  color: #00c3ff;
}
.user_qianming {
  font-size: 14px;
  color: #999;
}

.user_num {
  width: 20vw;
  height: 100%;
  display: flex;
  align-items: center;
  flex-direction: row-reverse;
}

.user_num > div {
  text-align: center;
  border-right: 1px dotted #999;
  box-sizing: border-box;
  line-height: 20px;
}

.num_text {
  font-size: 10px;
  color: #999;
}

.num_number {
  font-size: 20px;
  color: #333;
}
.el-menu-item>span {
  font-size: 16px;
  color: #999;
}

/*下面部分样式*/
.person_body {
  width: 100%;
  margin-top: 20vh;
  
  display: flex;
  flex-direction: column;
  height: 55vh;
  background-color: rgb(244, 239, 239);
  /* flex-direction: column; */
  justify-content: center;
  flex-wrap: wrap;
  align-content: center;
background-color: rgb(153, 150, 150);
  border-radius: 5px;
}
.box1 {
  padding: 1vh;
        border: 2px solid rgb(153, 150, 150);
        border-radius: 5px;
        box-sizing: border-box;
        background-color: rgb(148, 44, 44);
        /* calc为CSS3内容 */
        width: 95%;
        height: 25%;
        background-image: url("../assets/template/卧室控件.jpg");
        background-size: 100% 100%;
        background-position: center center;
        overflow: auto;
        background-repeat: no-repeat;
 }
 .ziti{
  font-family:Arial, Helvetica, sans-serif ;
 }
 .zhanwei{
  width: 100%;
  height: 70%;
 }
 .box2 {
  border: 2px solid rgb(153, 150, 150);
        border-radius: 5px;
        box-sizing: border-box;
        background-color: rgb(148, 44, 44);
        /* calc为CSS3内容 */
        width: 95%;
        height: 25%;
        background-image: url("../assets/template/厨房控件.jpg");
        background-size: 100% 100%;
        background-position: center center;
        overflow: auto;
        background-repeat: no-repeat;
 }
 .box3 {
  border: 2px solid rgb(153, 150, 150);
        border-radius: 5px;
        box-sizing: border-box;
        background-color: rgb(148, 44, 44);
        /* calc为CSS3内容 */
        width: 95%;
        height: 25%;
        background-image: url("../assets/template/卫生间控件.jpg");
        background-size: 100% 100%;
        background-position: center center;
        overflow: auto;
        background-repeat: no-repeat;
 }
 .box4 {
  border: 2px solid rgb(153, 150, 150);
        border-radius: 5px;
        box-sizing: border-box;
        background-color: rgb(148, 44, 44);
        /* calc为CSS3内容 */
        width: 95%;
        height: 25%;
        background-image: url("../assets/template/客厅控件.jpg");
        background-size: 100% 100%;
        background-position: center center;
        overflow: auto;
        background-repeat: no-repeat;
 }
.person_body_left {
  width: 27%;
  height: 600px;
  border-radius: 5px;
  margin-right: 3%;
  text-align: center;
}

.person_body_list {
  width: 100%;
  height: 50px;
  margin-top: 25px;
  font-size: 22px;
  border-bottom: 1px solid #f0f0f0;
  background-image: -webkit-linear-gradient(
    left,
    rgb(42, 134, 141),
    #e9e625dc 20%,
    #3498db 40%,
    #e74c3c 60%,
    #09ff009a 80%,
    rgba(82, 196, 204, 0.281) 100%
  );
  -webkit-text-fill-color: transparent;
  -webkit-background-clip: text;
  -webkit-background-size: 200% 100%;
  -webkit-animation: masked-animation 4s linear infinite;
}

.el-menu-item {
  margin-top: 22px;
}

.person_body_right {
  width: 70%;
  /* height: 500px; */
  border-radius: 5px;
  background-color: white;
}

.box-card {
  height: 500px;
}

/*ui样式*/
.el-button {
  width: 84px;
}

.container{
  width:100%;
  height: 85vh;
  background-image: url("../assets/beijing_m.jpg");
  background-size: 100% 100%;
  background-position: center center;
  overflow: auto;
  background-repeat: no-repeat;
}
.hcqStyle1{color:hsl(184,80%,25%);text-shadow:0 0 1px currentColor,/*highlight*/-1px -1px 1px hsl(184,80%,50%),0 -1px 1px hsl(184,80%,55%),1px -1px 1px hsl(184,80%,50%),/*light shadow*/1px 1px 1px hsl(184,80%,10%),0 1px 1px hsl(184,80%,10%),-1px 1px 1px hsl(184,80%,10%),/*outline*/-2px -2px 1px hsl(184,80%,15%),-1px -2px 1px hsl(184,80%,15%),0 -2px 1px hsl(184,80%,15%),1px -2px 1px hsl(184,80%,15%),2px -2px 1px hsl(184,80%,15%),2px -1px 1px hsl(184,80%,15%),2px 0 1px hsl(184,80%,15%),2px 1px 1px hsl(184,80%,15%),-2px 0 1px hsl(184,80%,15%),-2px -1px 1px hsl(184,80%,15%),-2px 1px 1px hsl(184,80%,15%),/*dark shadow*/2px 2px 2px hsl(184,80%,5%),1px 2px 2px hsl(184,80%,5%),0 2px 2px hsl(184,80%,5%),-1px 2px 2px hsl(184,80%,5%),-2px 2px 2px hsl(184,80%,5%)}
    

</style>