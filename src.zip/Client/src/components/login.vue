<template>
  <div>
  <div v-if="isPC" class="loginbody">
    <div class="logindata">
      <div class="logintext">
        <h2>Welcome</h2>
      </div>
      <div class="formdata">
        <el-form ref="form" :model="form" :rules="rules">
          <el-form-item prop="username">
            <el-input
              v-model="form.username"
              clearable
              placeholder="请输入账号"
            ></el-input>
          </el-form-item>
          <el-form-item prop="password">
            <el-input
              v-model="form.password"
              clearable
              placeholder="请输入密码"
              show-password
            ></el-input>
          </el-form-item>
        </el-form>
        <div class="tool">
        <div>
          <el-checkbox v-model="checked" @change="remenber"
            >记住密码</el-checkbox
          >
        </div>
        <div>
          <router-link v-if="isPC" to = "/Register">点我注册</router-link>
        </div>
      </div>
      <div class="butt">
        <el-button type="primary" @click.native.prevent="login('form')" style="width: 100%;"
          >登录</el-button
        >
        
        <!-- <el-button class="shou" @click="register">注册</el-button> -->
      </div>
      </div>
      
      
    </div>
  </div>

  <div v-if="!isPC" class="loginbody2">

      <div class="logintext2">
        <h2>Welcome</h2>
      </div>
      <div class="formdata2">
        <el-form ref="form" :model="form" :rules="rules">
          <el-form-item prop="username">
            <el-input
              v-model="form.username"
              clearable
              placeholder="请输入账号"
            ></el-input>
          </el-form-item>
          <el-form-item prop="password">
            <el-input
              v-model="form.password"
              clearable
              placeholder="请输入密码"
              show-password
            ></el-input>
          </el-form-item>
        </el-form>
      <div class="butt2">
        <el-button type="primary" @click.native.prevent="login('form')" style="width: 100%;"
          >登录</el-button
        >
        
        <!-- <el-button class="shou" @click="register">注册</el-button> -->
      </div>
      </div>
      
      
  </div>
</div>
</template>

<script>
// import axios from 'axios';
// import { login } from "@/api/login";
// import { setToken } from "@/request/auth";
import { mapState } from 'vuex';
export default {
  name: "login",
  computed:mapState([
    'token'
  ]),
  data() {
    return {
      isPC: this.isPCNot(),
      form: {
        password: "",
        username: "",
      },
      checked: false,
      rules: {
        username: [
          { required: true, message: "请输入用户名", trigger: "blur" },
          { max: 15,min:1, message: "请介于6-15位", trigger: "blur" },
        ],
        password: [
          { required: true, message: "请输入密码", trigger: "blur" },
          { max: 15, min:1,message: "请介于6-15位", trigger: "blur" },
        ],
        phonenumber: [
          { required: true, message: "请输入电话号码", trigger: "blur" },
          { pattern: /^1[3|4|5|6|7|8|9][0-9]\d{8}$/, message: "非法的电话号码", trigger: "blur" },
        ],
      },
    };
  },
  mounted() {
      if(localStorage.getItem("news")){
        this.form=JSON.parse(localStorage.getItem("news"))
        this.checked=true
      }
  },
  methods: {
    isPCNot() {
            var userAgentInfo = navigator.userAgent;
            var Agents = ["Android", "iPhone",
                "SymbianOS", "Windows Phone",
                "iPad", "iPod"];
            var flag = true;
            for (var v = 0; v < Agents.length; v++) {
                if (userAgentInfo.indexOf(Agents[v]) > 0) {
                    flag = false;
                    break;
                }
            }
            return flag;
        },
    login(form) {
      console.log(this.form.password);
      console.log(this.form.phonenumber);
      console.log(this.form.username);
      this.$http.get('/login',{
        params:{
          username:this.form.username,
          password:this.form.password
        }
      }).then(
        (res)=>{
          console.log(res);
          if(res.data.code=="200"){
            if(this.isPC){
              
              this.$router.push('/person');
              this.$store.commit('Get_Token',res.data.token);
              var storage=window.localStorage;
              storage.setItem("token",this.$store.state.token);
              storage.setItem("type",this.$store.state.type);
              storage.setItem("roomname",this.$store.state.roomname);
              storage.setItem("scenename",this.$store.state.scenename);
              storage.setItem("nickname",this.$store.state.form.nickname);
              storage.setItem("id",this.$store.state.form.id);              
              alert("登录成功");
            }else{
                   
              this.$store.commit('Get_Token',res.data.token);   
              var storage=window.localStorage;
              storage.setItem("token",this.$store.state.token);
              storage.setItem("type",this.$store.state.type);
              storage.setItem("roomname",this.$store.state.roomname);
              storage.setItem("scenename",this.$store.state.scenename);
              storage.setItem("nickname",this.$store.state.form.nickname);
              storage.setItem("id",this.$store.state.form.id); 
              this.$router.push('/person_mob');
             
              alert("登录成功");
            }
            
          }else{
            alert("错误代码"+res.data.code);
          }
        }
      ).catch(
        (res)=>{
          alert("网络错误，连不上");
          console.log(res);
        }
      );
    },
    remenber(data){
      this.checked=data
      if(this.checked){
          localStorage.setItem("news",JSON.stringify(this.form))
      }else{
        localStorage.removeItem("news")
      }
    },
    forgetpas() {
      this.$message({
        type:"info",
        message:"暂不支持",
        showClose:true
      })
    },
    register() {

    },
  },
};
</script>

<style scoped>
.loginbody {
  width: 100%;
  height: 100%;
  background-image: url("../../assets/images/login-bg.jpg");
  background-size: 100% 100%;
  background-position: center center;
  overflow: auto;
  background-repeat: no-repeat;
  position: fixed;
  line-height: 100%;
  padding-top: 150px;
}

.logintext {
  margin-bottom: 20px;
  line-height: 50px;
  text-align: center;
  font-size: 30px;
  font-weight: bolder;
  color: white;
  text-shadow: 2px 2px 4px #000000;
}

.logindata {
  width: 400px;
  height: 300px;
  transform: translate(-50%);
  margin-left: 50%;
}

.tool {
  display: flex;
  justify-content: space-between;
  color: #606266;
}

.butt {
  margin-top: 10px;
  text-align: center;
  width: 100%;
}

.shou {
  cursor: pointer;
  color: #606266;
}
.formdata{
  padding: 30px;
  border-radius: 5%;
  background-color: #b8b9bc;
}

.loginbody2 {
  width: 100%;
  height: 100%;
  background-image: url("../../assets/images/login-bg.jpg");
  background-size: 100% 100%;
  background-position: center center;
  overflow: auto;
  background-repeat: no-repeat;
  position: fixed;
  line-height: 100%;
  padding-top: 20vh;
}

.logintext2 {
  margin-bottom: 20px;
  line-height: 3vh;
  text-align: center;
  font-size: 3vh;
  font-weight: bolder;
  color: white;
  text-shadow: 2px 2px 4px #000000;
}

.logindata2 {
  width: 400px;
  height: 300px;
  transform: translate(-50%);
  margin-left: 50%;
}

.tool2 {
  display: flex;
  justify-content: space-between;
  color: #606266;
}

.butt2 {
  margin-top: 10px;
  text-align: center;
  width: 100%;
}

.shou2 {
  cursor: pointer;
  color: #606266;
}
.formdata2{
  margin-left: 5vh;
  margin-right: 5vh;
  padding: 2vh;
  border-radius: 5%;
  background-color: #b8b9bc;
}
</style>