<template>
  <div>
    <div v-if="isPC" class="body">
      <div style="height:100%">
        <el-menu
          :default-active="activeIndex2"
          router="true"
          class="el-menu-demo"
          mode="horizontal"
          @select="handleSelect"
          background-color="#545c64"
          text-color="#fff"
          active-text-color="#ffd04b"
          >
          <el-menu-item index="/person">个人主页</el-menu-item>
          <el-submenu index="/2">
            <template slot="title">创建场所</template>
            <el-menu-item index="/Scene_List" @click="this.$store.state.type=4">场所:客厅</el-menu-item>
            <el-menu-item index="/Scene_List" @click="this.$store.state.type=2">场所:厨房</el-menu-item>
            <el-menu-item index="/Scene_List" @click="this.$store.state.type=1">场所:卧室</el-menu-item>
            <el-menu-item index="/Scene_List" @click="this.$store.state.type=3">场所:卫生间</el-menu-item>
          </el-submenu>
          <el-menu-item index="/device_quick">设备速览</el-menu-item>
        </el-menu>
      </div>

      
      <router-view></router-view>
    </div>

    <div v-if="!isPC" class="body2">
      <div style="height:8vh;width:100%">
        <el-menu
          :default-active="activeIndex2"
          router="true"
          class="el-menu-demo"
          mode="horizontal"
          @select="handleSelect"
          background-color="#545c64"
          text-color="#fff"
          active-text-color="#ffd04b"
          >
          <el-menu-item index="/person">个人主页</el-menu-item>
          <el-menu-item index="/device_quick">设备速览</el-menu-item>
        </el-menu>
        <router-view></router-view>
      </div> 
    </div>
  </div>
</template>

<script>
// import { login } from "@/api/login";
// import { setToken } from "@/request/auth";

export default {
  name: "login",
  data() {
    return {
      isPC: this.isPCNot(),
      form: {
        password: "",
        username: "",
        phonenumber:"",
      },
      checked: false,
      rules: {
        username: [
          { required: true, message: "请输入用户名", trigger: "blur" },
          { max: 15,min:1, message: "请介于6-15位", trigger: "blur" },
        ],
        password: [
          { required: true, message: "请输入密码", trigger: "blur" },
          { max: 15, min:1,message: "请介于6-15位", trigger: "blur" },
        ],
        phonenumber: [
          { required: true, message: "请输入电话号码", trigger: "blur" },
          { pattern: /^1[3|4|5|6|7|8|9][0-9]\d{8}$/, message: "非法的电话号码", trigger: "blur" },
        ],
      },
      activeIndex2: '1'
    };
  },
  methods: {
    isPCNot() {
            var userAgentInfo = navigator.userAgent;
            var Agents = ["Android", "iPhone",
                "SymbianOS", "Windows Phone",
                "iPad", "iPod"];
            var flag = true;
            for (var v = 0; v < Agents.length; v++) {
                if (userAgentInfo.indexOf(Agents[v]) > 0) {
                    flag = false;
                    break;
                }
            }
            return flag;
        },
      handleOpen(key, keyPath) {
        console.log(key, keyPath);
      },
      handleClose(key, keyPath) {
        console.log(key, keyPath);
      }
    }
};
</script>

<style scoped>
.tac{
  width: 30%;
  height: 100%;
}

.body{
  height: 100%;
}
.body2{
  height: 100vh;
}
</style>