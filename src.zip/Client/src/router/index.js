import VueRouter from "vue-router";
import Vue from "vue";
import login from "../components/login.vue";
import register from "../components/Register.vue";
import Mainframe from "../components/Mainframe.vue";
import person from "../components/person.vue";
import person_m from "../components/person_m.vue";
import scene from "../components/scene.vue";
import bedroom from "../components/bedroom.vue";
import bedroom_m from "../components/bedroom_m.vue";
import roomlist from "../components/roomlist.vue";
import device_quick from "../components/device_quick.vue";
// import
Vue.use(VueRouter);

const router = new VueRouter({
  routes: [
    { path: "/", redirect: "/login" },
    { path: "/login", component: login },
    { path: "/register", component: register },
    {
      path: "/Scene_List",
      component: bedroom,
    },
    {
      path: "/device_quick",
      component: device_quick,
    },
    { path: "/Scene_List/Room_List/Device", component: scene },
    { path: "/Scene_List/Room_List", component: roomlist },
    {
      path: "/Mainframe",
      component: Mainframe,
      children: [
        {
          path: "/person",
          component: person,
        },
        {
          path: "/person_mob",
          component: person_m,
        },
        { path: "/:id", component: scene },
      ],
    },
  ],
});

export default router;
