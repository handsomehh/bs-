<template>
  <div>

  <el-dialog
  title="新建一个场所"
  :visible.sync="dialogVisible"
  width="40%"
  :before-close="handleClose">
  <el-form :model="form" :rules="rules" ref="form" label-width="150px">
      <div class="updateinfo">
  <div>
          <el-form-item label="日期" prop="date">
            <el-input maxlength="20" v-model="form.date"></el-input>
          </el-form-item>
          <el-form-item label="名称" prop="scenename">
            <el-input maxlength="20" v-model="form.scenename"></el-input>
          </el-form-item>
          <el-form-item label="备注消息" prop="msg">
            <el-input maxlength="20" v-model="form.msg"></el-input>
          </el-form-item> 
  </div>
  </div>
  </el-form>
  <span slot="footer" class="dialog-footer">
    <el-button @click="handleClose">取 消</el-button>
    <el-button type="primary" @click="submit">提 交</el-button>
  </span>
</el-dialog>
  </div>
</template>

<script>
// import { userInfo, updateUser } from "@/api/user.js";

export default {
  data() {
    return {
      dialogVisible: false,
      form: {
        date:"",
        scenename:"",
        msg:""
      },
      rules: {
        scenename: [
          { required: true, message: "请输入房间名", trigger: "blur" },
        ],
      },
    };
  },
  mounted() {

  },
  methods: {
    open() {
      this.dialogVisible = true;
      console.log(this.data);
    },
    load() {
      // userInfo(this.$store.state.id)
      //   .then((res) => {
      //     console.log(res);
      //     Object.assign(this.form, res.data);
      //   })
      //   .catch((err) => {
      //     console.log(err);
      //   });
    },
    submit() {
      this.$http.post('/room',{
        token:this.$store.state.token,
        type:this.$store.state.type,
        date:this.form.date,
        scenename:this.form.scenename,
        msg:this.form.msg,
      }).then((res)=>{
        console.log(res);
        if(res.data.code=="200"){
          
          this.dialogVisible = false;
          // Object.assign(this.$store.state.form, this.form);
          this.$emit("flesh");
          alert("Update succeed");
        }else{
          alert("update error");
        }
      }).catch((res)=>{
        alert("房间名和已有房间名重复，或其他特殊原因");
        })
      // updateUser(this.form)
      //   .then((res) => {
      //     console.log(res);
      //     this.dialogVisible = false;
      //     this.$emit("flesh");
      //   })
      //   .catch((err) => {
      //     console.log(err);
      //   });
    },
    handleClose() {
      this.dialogVisible = false;
      this.$emit("flesh");
    },
  },
};
</script>

<style scoped>
.updateinfo {
  height: 200px;
  overflow: auto;
}
.left {
  /* width: 330px; */
  float: left;
}
.right {
  overflow: hidden;
}
</style>